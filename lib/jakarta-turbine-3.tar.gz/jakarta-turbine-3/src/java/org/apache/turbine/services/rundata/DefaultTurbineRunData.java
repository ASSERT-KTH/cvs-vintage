package org.apache.turbine.services.rundata;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.util.Locale;
import java.util.Vector;
import java.util.Hashtable;
import java.io.PrintWriter;
import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.turbine.Turbine;
import org.apache.turbine.ParameterParser;
import org.apache.fulcrum.security.util.AccessControlList;
import org.apache.fulcrum.pool.Recyclable;
import org.apache.fulcrum.pool.RecyclableSupport;
import org.apache.fulcrum.localization.Localization;
import org.apache.fulcrum.mimetype.TurbineMimeTypes;
import org.apache.fulcrum.security.entity.User;
import org.apache.fulcrum.util.parser.CookieParser;
import org.apache.commons.collections.FastHashMap;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

/**
 * DefaultTurbineRunData is the default implementation of the
 * TurbineRunData interface, which is distributed by the Turbine
 * RunData service, if another implementation is not defined in
 * the default or specified RunData configuration.
 * TurbineRunData is an extension to RunData, which
 * is an interface to run-rime information that is passed
 * within Turbine. This provides the threading mechanism for the
 * entire system because multiple requests can potentially come in
 * at the same time.  Thus, there is only one RunData implementation
 * for each request that is being serviced.
 *
 * <p>DefaultTurbineRunData implements the Recyclable interface making
 * it possible to pool its instances for recycling.
 *
 * @author <a href="mailto:ilkka.priha@simsoft.fi">Ilkka Priha</a>
 * @author <a href="mailto:jon@latchkey.com">Jon S. Stevens</a>
 * @author <a href="mailto:bhoeneis@ee.ethz.ch">Bernie Hoeneisen</a>
 * @author <a href="mailto:dlr@finemaltcoding.com">Daniel Rall</a>
 * @version $Id: DefaultTurbineRunData.java,v 1.16 2002/05/29 23:58:27 jon Exp $
 */
public class DefaultTurbineRunData
    extends RecyclableSupport
    implements TurbineRunData,
               Recyclable
{
    private static final Log log
        = LogFactory.getLog( DefaultTurbineRunData.class );

    /**
     * The default locale.
     */
    private static Locale defaultLocale;

    /**
     * The default locale checked flag.
     */
    private static boolean defaultLocaleChecked;

    /**
     * The default charset.
     */
    private static String defaultCharSet;

    /**
     * The default charset checked flag.
     */
    private static boolean defaultCharSetChecked;

    /**
     * A reference to the GET/POST data parser.
     */
    private ParameterParser parameters;

    /**
     * A reference to a cookie parser.
     */
    public CookieParser cookies;

    /**
     * The servlet request interface.
     */
    private HttpServletRequest req;

    /**
     * The servlet response interface.
     */
    private HttpServletResponse res;

    /**
     * The servlet session information.
     */
    private HttpSession session;

    /**
     * The servlet configuration.
     */
    private ServletConfig config;

    /**
     * The servlet context information.
     * Note that this is from the
     * "Turbine" Servlet context.
     */
    private ServletContext servletContext;

    /**
     * The access control list.
     */
    private AccessControlList acl;

    /**
     * Cached action name to execute for this request.
     */
    private String action;

    /**
     * The character encoding of template files.
     */
    private String templateEncoding;

    /**
     * The user object.
     */
    private User user;

    /**
     * This is what will build the <title></title> of the document.
     */
    private String title;

    /**
     * The locale.
     */
    private Locale locale;

    /**
     * The HTTP charset.
     */
    private String charSet;

    /**
     * The HTTP content type to return.
     */
    private String contentType = "text/html";

    /**
     * If this is set, also set the status code to 302.
     */
    private String redirectURI;

    /**
     * The HTTP status code to return.
     */
    private int statusCode = HttpServletResponse.SC_OK;

    /**
     * This is a vector to hold critical system errors.
     */
    private Vector errors = new Vector();

    /**
     * @see #getRemoteAddr()
     */
    private String remoteAddr;

    /**
     * @see #getRemoteHost()
     */
    private String remoteHost;

    /**
     * @see #getUserAgent()
     */
    private String userAgent;

    /**
     * A holder for stack trace.
     */
    private String stackTrace;

    /**
     * A holder ofr stack trace exception.
     */
    private Throwable stackTraceException;

    /**
     * Put things here and they will be shown on the default Error
     * screen.  This is great for debugging variable values when an
     * exception is thrown.
     */
    private Hashtable varDebug = new Hashtable();

    private String target;
    private String message;
    private FastHashMap temp;

    // These were part of server data

    /** Cached serverName, */
    private String  serverName = null;

    /** Cached serverPort. */
    private int serverPort = 80;

    /** Cached serverScheme. */
    private String  serverScheme = null;

    /** Cached script name. */
    private String  scriptName = null;

    /** Cached context path. */
    private String  contextPath = null;

    public void setTarget(String target)
    {
        this.target = target;
    }

    public String getTarget()
    {
        return target;
    }

    public boolean hasTarget()
    {
        return (target != null);
    }

    public void setTemp(String key, Object value)
    {
        temp.put(key, value);
    }

    public Object getTemp(String key)
    {
        return temp.get(key);
    }

    /**
     * Constructs a run data object.
     */
    public DefaultTurbineRunData()
    {
        super();

        // This only needs to be made once. We will
        // clear out the mappings when the RunData object
        // is recycled.
        temp = new FastHashMap();
    }

    /**
     * Recycles a run data object.
     */
    public void recycle()
    {
        super.recycle();
    }

    /**
     * Disposes a run data object.
     */
    public void dispose()
    {
        target = null;
        parameters = null;
        cookies = null;
        req = null;
        res = null;
        session = null;
        config = null;
        servletContext = null;
        acl = null;
        action = null;
        templateEncoding = null;
        user = null;
        title = null;
        locale = null;
        charSet = null;
        contentType = "text/html";
        redirectURI = null;
        statusCode = HttpServletResponse.SC_OK;
        errors.clear();
        remoteAddr = null;
        remoteHost = null;
        userAgent = null;
        stackTrace = null;
        stackTraceException = null;
        varDebug.clear();
        message = null;

        // Clear all the values from the temporary
        // storage.
        temp.clear();

        //serverName = null;
        //serverPort = 80;
        //serverScheme = null;
        //scriptName = null;
        //contextPath = null;

        super.dispose();
    }

    // ***************************************
    // Implementation of the RunData interface
    // ***************************************

    /**
     * Gets the parameters.  if this is the first time calling
     * this method since the rundata was borrowed from the pool
     * the request will be parsed.
     *
     * @return a parameter parser.
     */
    public ParameterParser getParameters()
    {
        // Parse the parameters first, if not yet done.
        if ((this.parameters != null) &&
            (this.parameters.getRequest() == null))
        {
            this.parameters.setRequest(this.req);
        }
        return this.parameters;
    }

    /**
     * Gets the cookies.
     *
     * @return a cookie parser.
     */
    public CookieParser getCookies()
    {
        return this.cookies;
    }

    /**
     * Gets the servlet request.
     *
     * @return the request.
     */
    public HttpServletRequest getRequest()
    {
        return this.req;
    }

    /**
     * Gets the servlet response.
     *
     * @return the resposne.
     */
    public HttpServletResponse getResponse()
    {
        return this.res;
    }

    /**
     * Gets the servlet session information.
     *
     * @return the session.
     */
    public HttpSession getSession()
    {
        return session;
    }

    /**
     * Gets the servlet configuration used during servlet init.
     *
     * @return the configuration.
     */
    public ServletConfig getServletConfig()
    {
        return this.config;
    }

    /**
     * Gets the servlet context used during servlet init.
     *
     * @return the context.
     */
    public ServletContext getServletContext()
    {
        return this.servletContext;
    }

    /**
     * Gets the access control list.
     *
     * @return the access control list.
     */
    public AccessControlList getACL()
    {
        return acl;
    }

    /**
     * Sets the access control list.
     *
     * @param acl an access control list.
     */
    public void setACL(AccessControlList acl)
    {
        this.acl = acl;
    }

    /**
     * Whether or not an action has been defined.
     *
     * @return true if an action has been defined.
     */
    public boolean hasAction()
    {
        return (this.action != null &&
                 this.action.length() > 0 &&
                 !this.action.equalsIgnoreCase("null"));
    }

    /**
     * Gets the action. It returns an empty string if null so
     * that it is easy to do conditionals on it based on the
     * equalsIgnoreCase() method.
     *
     * @return a string, "" if null.
     */
    public String getAction()
    {
        return (hasAction() ? this.action : "");
    }

    /**
     * Sets the action for the request.
     *
     * @param action a atring.
     */
    public void setAction (String action)
    {
        this.action = action;
    }

    /**
     * Gets the character encoding to use for reading template files.
     *
     * @return the template encoding or null if not specified.
     */
    public String getTemplateEncoding()
    {
        return templateEncoding;
    }

    /**
     * Sets the character encoding to use for reading template files.
     *
     * @param encoding the template encoding.
     */
    public void setTemplateEncoding(String encoding)
    {
        templateEncoding = encoding;
    }

    /**
     * Gets the title of the page.
     *
     * @return a string.
     */
    public String getTitle()
    {
        return (this.title == null ? "" : this.title);
    }

    /**
     * Sets the title of the page.
     *
     * @param title a string.
     */
    public void setTitle (String title)
    {
        this.title = title;
    }

    /**
     * Checks if a user exists in this session.
     *
     * @return true if a user exists in this session.
     */
    public boolean userExists()
    {
        user = getUserFromSession();
        return (user != null);
    }

    /**
     * Gets the user.
     *
     * @return a user.
     */
    public User getUser()
    {
        return this.user;
    }

    /**
     * Sets the user.
     *
     * @param user a user.
     */
    public void setUser(User user)
    {
        this.user = user;
    }

    /**
     * Attempts to get the User object from the session.  If the user
     * does not exist in the session, <code>null</code> is returned.
     *
     * <p> Anyone overriding this method should be sure to leverage
     * the <code>SessionBindingEventProxy</code> when pulling the
     * <code>User</code> object from the session, allowing hook
     * functions to be called on the listener when it is removed from
     * the session (which happens on session timeout).
     *
     * @param session The session to retrieve a <code>User</code>
     * object from.
     * @return The retreived user, or <code>null</code> if errors
     * occur.
     * @see org.apache.turbine.services.rundata.SessionBindingEventProxy
     * @see org.apache.fulcrum.security.entity.User
     * @see org.apache.fulcrum.security.session.SessionBindingListener
     */
    public static User getUserFromSession(HttpSession session)
    {
        try
        {
            SessionBindingEventProxy proxy =
                (SessionBindingEventProxy) session
                .getAttribute(User.SESSION_KEY);

            // If the user isn't yet logged in, return null so that
            // the session validator can take the correct action
            // (i.e. make a temporary anonymous user).
            return (proxy == null ? null : (User) proxy.getListener());
        }
        catch (ClassCastException e)
        {
            String message = "User object did not implement User interface.  "
                + "if you are sure the interface is implemented, the user " +
                "object in the session and this class may be loaded from " +
                "different classloaders.  This has been known to happen " +
                "when using multiple turbine apps in tomcat that interact " +
                "through the use of RequestDispatcher.include or forward.";
            if ( log != null )
            {
                log.error(message, e);
            }
            else 
            {
                System.err.println(message);
                e.printStackTrace();
            }
            
            return null;
        }
    }

    /**
     * Allows one to invalidate the user in a session.
     *
     * @param session The session from which to remove the user.
     * @return Whether the user was removed from the session.
     */
    public static boolean removeUserFromSession(HttpSession session)
    {
        try
        {
            session.removeAttribute(User.SESSION_KEY);
        }
        catch (Exception e)
        {
            return false;
        }
        return true;
    }

    /**
     * Retrieves the ACL from the session
     */
    public static AccessControlList getACLFromSession(HttpSession session)
    {
        try
        {
            AccessControlList acl = (AccessControlList)
                session.getAttribute(AccessControlList.SESSION_KEY);

            // If the acl isn't yet defined, return null
            return (acl == null ? null : acl);
        }
        catch (ClassCastException e)
        {
            return null;
        }
    }

    /**
     * Allows one to invalidate the acl in a session.
     *
     * @param session An HttpSession.
     * @return True if acl was invalidated.
     */
    public static boolean removeACLFromSession(HttpSession session)
    {
        try
        {
            session.removeAttribute(AccessControlList.SESSION_KEY);
        }
        catch (Exception e)
        {
            return false;
        }
        return true;
    }

    /**
     * Attempts to get the user from the session. If it does
     * not exist, it returns null.
     *
     * @return a user.
     */
    public User getUserFromSession()
    {
        return getUserFromSession(session);
    }

    /**
     * Allows one to invalidate the user in the default session.
     *
     * @return true if user was invalidated.
     */
    public boolean removeUserFromSession()
    {
        return removeUserFromSession(session);
    }

    /**
     * Attempts to get the ACL from the session. If it does
     * not exist, it returns null.
     *
     * @return a acl.
     */
    public AccessControlList getACLFromSession()
    {
        return getACLFromSession(session);
    }

    /**
     * Allows one to invalidate the acl in the default session.
     *
     * @return true if acl was invalidated.
     */
    public boolean removeACLFromSession()
    {
        return removeACLFromSession(session);
    }

    /**
     * Gets the print writer.
     *
     * @return a print writer.
     * @throws IOException
     */
    public PrintWriter getOut()
        throws IOException
    {
        return res.getWriter();
    }

    /**
     * Gets the default locale defined by properties named
     * "locale.default.lang" and "locale.default.country".
     * If neither property is defined, it will use the Local.getDefault()
     * method to return the appropriate Locale for the installed JVM.
     *
     * @return the default locale.
     */
    protected static Locale getDefaultLocale()
    {
        if (!defaultLocaleChecked)
        {
            /* Get the default locale and cache it in a static variable. */
            String lang = Turbine.getConfiguration()
                .getString("locale.default.language");
            String country = Turbine.getConfiguration()
                .getString("locale.default.country");
            if (lang != null)
            {
                defaultLocale = country != null ?
                    new Locale(lang,country) : new Locale(lang,"");
            }
            else if (country != null)
            {
                defaultLocale = new Locale("",country);
            }
            else
            {
                defaultLocale = Locale.getDefault();
            }
            defaultLocaleChecked = true;
        }
        return defaultLocale;
    }

    /**
     * Gets the default charset defined by a property named
     * "locale.default.charset" or by the default Locale.
     *
     * @return the name of the default charset.
     */
    protected String getDefaultCharSet()
    {
        if (!defaultCharSetChecked)
        {
            /* Get the default charset and cache 
               it in a static variable. */
            defaultCharSet = Turbine.getConfiguration().
                getString("locale.default.charset");

            if (defaultCharSet == null)
            {
                /* Default charset isn't specified, 
                   get the locale specific one. */
                Locale locale = getLocale();
                defaultCharSet = TurbineMimeTypes.getCharSet(locale);
            }
            defaultCharSetChecked = true;
        }
        return defaultCharSet;
    }

    /**
     * Gets the locale. If it has not already been defined with
     * setLocale(), then the Localization service is used to determine
     * the right Locale based on the HttpServletRequest. If that is
     * not possible, then the getDefaultLocale() method is used.
     *
     * @return the Locale.
     */
    public Locale getLocale()
    {
        if (locale == null)
        {
            locale = Localization.getLocale(getRequest());
            if (locale == null)
            {
                locale = getDefaultLocale();
            }
        }
        return locale;
    }

    /**
     * Sets the Locale.
     *
     * @param locale the new Locale.
     */
    public void setLocale(Locale locale)
    {
        this.locale = locale;
    }

    /**
     * Gets the charset. If it has not already been defined with
     * setCharSet(). It will then try to get the getDefaultCharSet().
     * If that isn't defined, then the Localization/Mimetype service is 
     * used to determine the right charset based on the 
     * HttpServletRequest. Please note that this ordering is still up
     * in the air and may change in the near future as more testing is done. 
     * The issue is that sometimes, even though the Locale
     * is dynamic, the charset should always be 8859_1. So, the current
     * ordering allows us to just define things as always being 8859_1 which
     * may or may not be correct.
     *
     * @return the charset.
     */
    public String getCharSet()
    {
        if (charSet == null)
        {
            charSet = getDefaultCharSet();
            if (charSet == null)
            {
                charSet = TurbineMimeTypes.getCharSet(getLocale());
            }
        }
        return charSet;
    }

    /**
     * Sets the charset.
     *
     * @param charset the name of the new charset.
     */
    public void setCharSet(String charset)
    {
        this.charSet = charset;
    }

    /**
     * Gets the HTTP content type to return. If a charset
     * has been specified, it is included in the content type.
     * If the charset has not been specified and the main type
     * of the content type is "text", the default charset is
     * included. If the default charset is undefined, but the
     * default locale is defined and it is not the US locale,
     * a locale specific charset is included.
     *
     * @return the content type or an empty string.
     */
    public String getContentType()
    {
        String ct = this.contentType;
        if (ct != null)
        {
            if (ct.startsWith("text/"))
            {
                String charset = getCharSet();
                if (charset != null)
                {
                    ct += "; charset=" + charset;
                }
            }
        }
        else
        {
            ct = "";
        }
        return ct;
    }

    /**
     * Sets the HTTP content type to return.
     *
     * @param ct a string.
     */
    public void setContentType(String ct)
    {
        this.contentType = ct;
    }

    /**
     * Gets the redirect URI. If this is set, also make sure to set
     * the status code to 302.
     *
     * @return a string, "" if null.
     */
    public String getRedirectURI()
    {
        return (this.redirectURI == null ? "" : redirectURI);
    }

    /**
     * Sets the redirect uri. If this is set, also make sure to set
     * the status code to 302.
     *
     * @param ruri a string.
     */
    public void setRedirectURI(String ruri)
    {
        this.redirectURI = ruri;
    }

    /**
     * Gets the HTTP status code to return.
     *
     * @return the status.
     */
    public int getStatusCode()
    {
        return statusCode;
    }

    /**
     * Sets the HTTP status code to return.
     *
     * @param sc the status.
     */
    public void setStatusCode(int sc)
    {
        this.statusCode = sc;
    }

    /**
     * Gets the cached server scheme.
     *
     * @return a string.
     */
    public String getServerScheme()
    {
        return serverScheme;
    }

    /**
     * Gets the cached server name.
     *
     * @return a string.
     */
    public String getServerName()
    {
        return serverName;
    }

    /**
     * Gets the cached server port.
     *
     * @return an int.
     */
    public int getServerPort()
    {
        return serverPort;
    }

    /**
     * Gets the cached context path.
     *
     * @return a string.
     */
    public String getContextPath()
    {
        return contextPath;
    }

    /**
     * Gets the cached script name.
     *
     * @return a string.
     */
    public String getScriptName()
    {
        return scriptName;
    }

    /**
     * Gets the IP address of the client that sent the request.
     *
     * @return a string.
     */
    public String getRemoteAddr()
    {
        if (this.remoteAddr == null)
        {
            this.remoteAddr = this.getRequest().getRemoteAddr();
        }

        return this.remoteAddr;
    }

    /**
     * Gets the qualified name of the client that sent the request.
     *
     * @return a string.
     */
    public String getRemoteHost()
    {
        if (this.remoteHost == null)
        {
            this.remoteHost = this.getRequest().getRemoteHost();
        }

        return this.remoteHost;
    }

    /**
     * Get the user agent for the request.
     *
     * @return a string.
     */
    public String getUserAgent()
    {
        if (this.userAgent == null)
        {
            this.userAgent = this.getRequest().getHeader("User-Agent");
        }

        return this.userAgent;
    }

    /**
     * Pulls a user and ACL object from the session and increments the access
     * counter and sets the last access date for the object.
     */
    public void populate()
    {
        user = getUserFromSession();

        if (user != null)
        {
            user.setLastAccessDate();
            user.incrementAccessCounter();
            user.incrementAccessCounterForSession();
        }
    }

    /**
     * <p>Saves this user object and ACL to the session.</p>
     *
     * <p>Anyone overriding this method should be sure to leverage
     * the <code>SessionBindingEventProxy</code> when adding the user
     * and acl into the session.  This allows hook functions to be called on
     * the <code>User</code> and <code>AccessControlList</code> when it is 
     * removed from the session (which happens on session timeout).</p>
     *
     * @see #setUser(User)
     * @see #setACL(AccessControlList)
     * @see org.apache.turbine.services.rundata.SessionBindingEventProxy
     * @see org.apache.fulcrum.security.entity.User
     * @see org.apache.fulcrum.security.util.AccessControlList
     * @see org.apache.fulcrum.security.session.SessionBindingListener
     */
    public void save()
    {
        session.setAttribute(
            User.SESSION_KEY, new SessionBindingEventProxy(user));
        session.setAttribute(
            AccessControlList.SESSION_KEY, (Object) acl);
    }

    /**
     * Gets the stack trace if set.
     *
     * @return the stack trace.
     */
    public String getStackTrace()
    {
        return stackTrace;
    }

    /**
     * Gets the stack trace exception if set.
     *
     * @return the stack exception.
     */
    public Throwable getStackTraceException()
    {
        return stackTraceException;
    }

    /**
     * Sets the stack trace.
     *
     * @param trace the stack trace.
     * @param exp the exception.
     */
    public void setStackTrace(String trace,
                              Throwable exp)
    {
        stackTrace = trace;
        stackTraceException = exp;
    }

    /**
     * Gets a table of debug variables.
     *
     * @return a hashtable for debug variables.
     */
    public Hashtable getVarDebug()
    {
        return varDebug;
    }

    // **********************************************
    // Implementation of the TurbineRunData interface
    // **********************************************

    /**
     * Gets the parameter parser without parsing the parameters.
     *
     * @return the parameter parser.
     */
    public ParameterParser getParameterParser()
    {
        return parameters;
    }

    /**
     * Sets the parameter parser.
     *
     * @param parser a parameter parser.
     */
    public void setParameterParser(ParameterParser parser)
    {
        parameters = parser;
    }

    /**
     * Gets the cookie parser without parsing the cookies.
     *
     * @return the cookie parser.
     */
    public CookieParser getCookieParser()
    {
        return cookies;
    }

    /**
     * Sets the cookie parser.
     *
     * @param parser a cookie parser.
     */
    public void setCookieParser(CookieParser parser)
    {
        cookies = parser;
    }

    /**
     * Sets the servlet request.
     *
     * @param req a request.
     */
    public void setRequest(HttpServletRequest req)
    {
        this.req = req;
    }

    /**
     * Sets the servlet response.
     *
     * @param res a response.
     */
    public void setResponse(HttpServletResponse res)
    {
        this.res = res;
    }

    /**
     * Sets the servlet session inforamtion.
     *
     * @param sess a session.
     */
    public void setSession(HttpSession sess)
    {
        this.session = sess;
    }

    /**
     * Setsthe servlet configuration used during servlet init.
     *
     * @param config a configuration.
     */
    public void setServletConfig(ServletConfig config)
    {
        this.config = config;
        if (config == null)
        {
            this.servletContext = null;
        }
        else
        {
            this.servletContext = config.getServletContext();
        }
    }

    // ********************
    // Miscellanous setters
    // ********************

    /**
     * Sets the cached server scheme that is stored in the server data.
     *
     * @param ss a string.
     */
    public void setServerScheme(String serverScheme)
    {
        this.serverScheme = serverScheme;
    }

    /**
     * Sets the cached server same that is stored in the server data.
     *
     * @param sn a string.
     */
    public void setServerName(String serverName)
    {
        this.serverName = serverName;
    }

    /**
     * Sets the cached server port that is stored in the server data.
     *
     * @param port an int.
     */
    public void setServerPort(int serverPort)
    {
        this.serverPort = serverPort;
    }

    /**
     * Sets the cached context path that is stored in the server data.
     *
     * @param cp a string.
     */
    public void setContextPath(String contextPath)
    {
        this.contextPath = contextPath;
    }

    /**
     * Sets the cached script name that is stored in the server data.
     *
     * @param sn a string.
     */
    public void setScriptName(String scriptName)
    {
        this.scriptName = scriptName;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }

    public String getMessage()
    {
        return message;
    }
}
