package org.apache.turbine.pipeline;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and 
 *    "Apache Turbine" must not be used to endorse or promote products 
 *    derived from this software without prior written permission. For 
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without 
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.io.IOException;

import java.util.Iterator;
import java.util.HashMap;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletException;

import org.apache.turbine.TemplateContext;
import org.apache.turbine.RunData;
import org.apache.turbine.Turbine;
import org.apache.turbine.TurbineException;
import org.apache.turbine.modules.Module;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iv.flash.util.Util;
import com.iv.flash.context.Context;
import com.iv.flash.context.BeanContext;
import com.iv.flash.util.FlashOutput;
import com.iv.flash.util.IVException;
import com.iv.flash.api.FlashFile;

/**
 * Renderer that use JGenerator to merge a SWT template with the template
 * context. The template context is wrapped in a JGenerator BeanContext.
 *
 * @author <a href="mailto:james@jamestaylor.org">James Taylor</a>
 * @version $Id: JGenRenderer.java,v 1.5 2002/06/04 12:17:07 jtaylor Exp $
 */
public class JGenRenderer
{
    // JGenerator expects to be initialized with the directory containing 
    // its 'iv.properties' file. In the future it is expected JGen will
    // support more methods of configuration to support embedded use more
    // cleanly.
    
    // FIXME: Need a better means to do one time initialization of JGenerator
    
    static
    {
     	Util.init( Turbine.getRealPath( "/WEB-INF/conf" ) );   
    }

    private static final Log log = LogFactory.getLog( JGenRenderer.class );

    private static final String TEMPLATE_PATH = "jgen.template.path";
    private static final String TEMPLATE_PATH_DEFAULT = "/templates/swt/";

    /**
     * RunData of the request this Renderer is for.
     */
    protected RunData data = null;

    /**
     * Construct a renderer for the given RunData.
     */
    public JGenRenderer(RunData data)
    {
        this.data = data;
    }
    
    /**
     * Process the request 
     * 
     * @param target the filename of the template.
     * @throws TurbineException Any exception trown while processing will be
     *         wrapped into a TurbineException and rethrown.
     */
    public void render( String target ) 
        throws TurbineException, IVException, IOException, ServletException
    {
        String templateRoot =
            Turbine.getConfiguration().getString( TEMPLATE_PATH,
                                                  TEMPLATE_PATH_DEFAULT );

        String targetPath = Turbine.getRealPath( templateRoot + target );
        
        log.debug( "SWT to render: " + targetPath );
        
        if ( targetPath == null )
        {
            throw new TurbineException( "No target path" );
        }
        
        // Build a BeanContext from the TemplateContext. Really we should 
        // be able to just make the TemplateContext the root object, but
        // it seems JXPath is dumber than I thought. 
        
        HashMap map = new HashMap();
        
        TemplateContext tc = Module.getTemplateContext( data );
        
        Iterator keyIterator = tc.keySet().iterator();

        String key;
        
        while( keyIterator.hasNext() )
        {
            key = (String) keyIterator.next();
            
            log.debug( "Key '" + key + "' added to context." );
            
            map.put( key, tc.get( key ) );
        }
        
        BeanContext context = 
        	new BeanContext( null, map );
            
        // Process the SWT with the context into a FlashOutput buffer
            
        FlashOutput fob = process( targetPath, context );
        
        send( fob, data.getResponse() );
    }

    /**
     * Process template<BR>
     * <UL>
     * <LI>parse template
     * <LI>process (perform substitutions and generator commands)
     * <LI>generate movie
     * </UL>
     *
     * @param fileName template file name
     * @param context  generator context
     * @return generated flash content
     * @exception IVException
     * @exception IOException
     */
    protected FlashOutput process( String fileName, Context context )
        throws IVException, IOException
    {
        FlashFile file = FlashFile.parse( fileName );

        file.processFile( context );

        return file.generate();
    }
    
    /**
     * Send generator output buffer to the client
     *
     * @param fob flash data to send
     * @param res response to send to
     * @exception ServletException
     * @exception IOException
     */ 
    protected void send( FlashOutput fob, HttpServletResponse res )
        throws ServletException, IOException
    {
        res.setContentLength( fob.getSize() );
        res.setContentType( "application/x-shockwave-flash" );

        ServletOutputStream sos = res.getOutputStream();

        sos.write( fob.getBuf(), 0, fob.getSize() );
    }
}
