package org.apache.turbine.workflow;

import org.apache.commons.digester.Digester;
import org.apache.commons.workflow.base.BaseRuleSet;

/**
 * <p><strong>RuleSet</strong> for the Step definitions supported by the
 * <em>web</em> library.  This library is normally associated with the
 * following namespace URI:</p>
 * <pre>
 *   http://jakarta.apache.org/commons/workflow/web
 * </pre>
 *
 * @author Craig R. McClanahan
 * @version $Revision: 1.1.1.1 $ $Date: 2001/09/23 07:06:24 $
 */

public class WebRuleSet extends BaseRuleSet {


    // ------------------------------------------------------------ Constructor


    /**
     * Construct a default instance of the <code>RuleSet</code>.
     */
    public WebRuleSet() {

        super();
        setPrefix("activity/");
        setNamespaceURI("http://jakarta.apache.org/commons/workflow/web");

    }


    // --------------------------------------------------------- Public Methods


    /**
     * <p>Add the set of Rule instances defined in this RuleSet to the
     * specified <code>Digester</code> instance, associating them with
     * our namespace URI (if any).  This method should only be called
     * by a Digester instance.</p>
     *
     * @param digester Digester instance to which the new Rule instances
     *  should be added.
     */
    public void addRuleInstances(Digester digester) {

        digester.addObjectCreate
            (prefix + "forward",
             "org.apache.turbine.workflow.ForwardStep");
        digester.addSetProperties
            (prefix + "forward");
        digester.addSetNext
            (prefix + "forward", "addStep",
             "org.apache.commons.workflow.Step");

        digester.addObjectCreate
            (prefix + "goto",
             "org.apache.turbine.workflow.GotoStep");
        digester.addSetProperties
            (prefix + "goto");
        digester.addSetNext
            (prefix + "goto", "addStep",
             "org.apache.commons.workflow.Step");

        digester.addObjectCreate
            (prefix + "include",
             getIncludeClass());
        digester.addSetProperties
            (prefix + "include");
        digester.addSetNext
            (prefix + "include", "addStep",
             "org.apache.commons.workflow.Step");

        digester.addObjectCreate
            (prefix + "populate",
             "org.apache.turbine.workflow.PopulateStep");
        digester.addSetProperties
            (prefix + "populate");
        digester.addSetNext
            (prefix + "populate", "addStep",
             "org.apache.commons.workflow.Step");
        digester.addObjectCreate
            (prefix + "populate/descriptor",
             "org.apache.commons.workflow.base.BaseDescriptor");
        digester.addSetProperties
            (prefix + "populate/descriptor");
        digester.addSetNext
            (prefix + "populate/descriptor", "addDescriptor",
             "org.apache.commons.workflow.Descriptor");

    }


    // ------------------------------------------------------ Protected Methods


    /**
     * Determine which version of the <code>Include</code> step we should
     * generate, based on which version of the Servlet API is visible in
     * our class loading hierarchy.
     */
    public String getIncludeClass() {

        try {
            Class.forName("javax.servlet.Filter");  // 2.3-or-later class
            return ("org.apache.turbine.workflow.IncludeStep23");
        } catch (ClassNotFoundException e) {
            return ("org.apache.turbine.workflow.IncludeStep22");
        }

    }


}
