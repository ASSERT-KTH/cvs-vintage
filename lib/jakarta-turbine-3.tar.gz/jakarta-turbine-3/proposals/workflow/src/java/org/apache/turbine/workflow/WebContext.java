package org.apache.turbine.workflow;

import java.util.EmptyStackException;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.collections.ArrayStack;
import org.apache.commons.workflow.Context;
import org.apache.commons.workflow.Scope;
import org.apache.commons.workflow.base.BaseContext;
import org.apache.turbine.RunData;

/**
 * <p><strong>WebContext</strong> is a specialized <code>Context</code>
 * implementation appropriate for web applications that run on top of a
 * Servlet 2.2 (or later) container.  It exposes the attributes associated
 * with requests, sessions, and the servlet context as <code>Scopes</code>
 * within the workflow management system.</p>
 *
 * @version $Revision: 1.1.1.1 $ $Date: 2001/09/23 07:06:24 $
 * @author Craig R. McClanahan
 */

public class WebContext 
    extends BaseContext 
{
    /**
     * The scope identifier for the scope associated with the current
     * servlet request.
     */
    public static final int RUNDATA_SCOPE = 2;


    /**
     * The scope name for the scope associated with the current
     * servlet request.
     */
    public static final String RUNDATA_SCOPE_NAME = "data";

    /**
     * The RunData that provides our associated "data" scope.
     */
    protected RunData data = null;

    public RunData getRunData() 
    {
        return data;
    }

    public void setRunData(RunData data) 
    {
        this.data = data;
        Scope oldScope = getScope(RUNDATA_SCOPE);
        if ((oldScope != null) && (oldScope instanceof RunData))
        {
            ((RunDataScope) oldScope).setRunData(data);
        }            
        else
        {
            addScope(RUNDATA_SCOPE, RUNDATA_SCOPE_NAME,new RunDataScope(data));
        }                     
    }
}
