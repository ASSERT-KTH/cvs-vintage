package org.apache.turbine.workflow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.apache.commons.workflow.base.BaseScope;
import org.apache.commons.workflow.util.MapEntry;
import org.apache.turbine.RunData;

public class RunDataScope
    extends BaseScope
{

    /**
     * Construct a new RunDataScope with no attached ServletContext.
     */
    public RunDataScope() 
    {
        super();
    }

    /**
     * Construct a RunDataScope associated with the specified
     * RunData.
     *
     * @param RunData The associated RunData
     */
    public RunDataScope(RunData data) 
    {
        super();
        setRunData(data);
    }

    /**
     * The servlet context with which we are associated.
     */
    protected RunData data = null;

    public RunData getRunData() 
    {
        return (this.data);
    }

    public void setRunData(RunData data) 
    {
        this.data = data;
    }
}
