
package org.apache.turbine.workflow;




/**
 * <p>JavaBean used in the demonstration web application.</p>
 *
 * @version $Revision: 1.1.1.1 $ $Date: 2001/09/23 07:06:23 $
 * @author Craig R. McClanahan
 */

public class DemoBean {


    // ------------------------------------------------------------- Properties


    private String firstName = "";

    public String getFirstName() {
        return (this.firstName);
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }


    private String lastName = "";

    public String getLastName() {
        return (this.lastName);
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    private String favoriteCar = "";

    public String getFavoriteCar() {
        return (this.favoriteCar);
    }

    public void setFavoriteCar(String favoriteCar) {
        this.favoriteCar = favoriteCar;
    }


    private String favoriteCity = "";

    public String getFavoriteCity() {
        return (this.favoriteCity);
    }

    public void setFavoriteCity(String favoriteCity) {
        this.favoriteCity = favoriteCity;
    }


    private String favoriteSport = "";

    public String getFavoriteSport() {
        return (this.favoriteSport);
    }

    public void setFavoriteSport(String favoriteSport) {
        this.favoriteSport = favoriteSport;
    }


    private String favoriteTeam = "";

    public String getFavoriteTeam() {
        return (this.favoriteTeam);
    }

    public void setFavoriteTeam(String favoriteTeam) {
        this.favoriteTeam = favoriteTeam;
    }


    public void reset() {
        this.firstName = "";
        this.lastName = "";
        this.favoriteCar = "";
        this.favoriteCity = "";
        this.favoriteSport = "";
        this.favoriteTeam = "";
    }


}
