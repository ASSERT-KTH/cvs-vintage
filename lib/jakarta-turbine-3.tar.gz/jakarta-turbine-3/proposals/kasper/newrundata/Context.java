package org.apache.turbine.newrundata;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * Defines an interface to provide client context information .
 *
 * @author <a href="mailto:dims@yahoo.com">Davanum Srinivas</a>
 * @author <a href="mailto:dims@yahoo.com">Kasper Nielsen</a>
 * @version CVS $Revision: 1.2 $ $Date: 2001/09/05 09:59:25 $
 *
 */

public interface Context {

    Object getAttribute(String name);

    URL getResource(String path) throws MalformedURLException;

    String getRealPath(String path) throws MalformedURLException;

    String getMimeType(String file);

    String getInitParameter(String name);
}
