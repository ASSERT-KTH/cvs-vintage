package org.apache.turbine.newrundata.servlet;


import java.net.MalformedURLException;
import java.net.URL;
import javax.servlet.ServletContext;


public class HttpContext {

    /** The ServletContext */
    private ServletContext servletContext = null;

    /**
     * Constructs a HttpContext object from a ServletContext object
     */
    public HttpContext (ServletContext servletContext)
    {
        this.servletContext = servletContext;
    }

    public Object getAttribute(String name)
    {
        return servletContext.getAttribute(name);
    }

    public URL getResource(String path)
       throws MalformedURLException
    {
       return servletContext.getResource(path);
    }

    public String getRealPath(String path)
    throws MalformedURLException
    {
        if (path.equals("/") == true) {
            String value = servletContext.getRealPath(path);
            if (value == null) {
                // Try to figure out the path of the root from that of WEB-INF
                value = this.servletContext.getResource("/WEB-INF").toString();
                value = value.substring(0,value.length()-"WEB-INF".length());
            }
            return value;
        }
        return servletContext.getRealPath(path);
    }

    public String getMimeType(String file)
    {
      return servletContext.getMimeType(file);
    }

    public String getInitParameter(String name)
    {
        return servletContext.getInitParameter(name);
    }
}
