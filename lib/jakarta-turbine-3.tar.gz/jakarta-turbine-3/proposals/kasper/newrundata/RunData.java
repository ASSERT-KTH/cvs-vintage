package org.apache.turbine.newrundata;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
import java.util.Map;
public interface RunData {

       //context stuff
       //should we base it on string keys instead of object keys?
       public boolean containsKey(Object key);
       public Object get(Object key);

       // no need to have a public Object put(Object key, Object value);
      // this will be provided in the default implementation TurbineRunData
      // users of rundata should use getTempStorage to store request specifik details.



      public Response getResponse();

      public Request getRequest();

      public Session getSession();

      public Context getContext();

      public Map getTempStorage();
}