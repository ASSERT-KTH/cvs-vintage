
--------------------------------------------------------------------------
-- TURBINE_USER
--------------------------------------------------------------------------
drop table if exists TURBINE_USER;

CREATE TABLE TURBINE_USER
(
    USER_ID INTEGER NOT NULL,
    PRIMARY KEY(USER_ID)
);
