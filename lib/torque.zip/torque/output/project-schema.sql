
# -----------------------------------------------------------------------
# RDF
# -----------------------------------------------------------------------
drop table if exists RDF;

CREATE TABLE RDF
(
    RDF_ID INTEGER NOT NULL AUTO_INCREMENT,
    TITLE VARCHAR (255),
    BODY VARCHAR (255),
    URL VARCHAR (255),
    AUTHOR VARCHAR (255),
    DEPT VARCHAR (255),
    PRIMARY KEY(RDF_ID)
);

# -----------------------------------------------------------------------
# PD_CONTINENT
# -----------------------------------------------------------------------
drop table if exists PD_CONTINENT;

CREATE TABLE PD_CONTINENT
(
    PD_CO_ID INTEGER NOT NULL,
    PD_CO_NAME_DE VARCHAR (50),
    PD_CO_NAME_EN VARCHAR (50),
    PD_CO_NAME_FR VARCHAR (50),
    PD_CO_NAME_IT VARCHAR (50),
    PRIMARY KEY(PD_CO_ID),
    UNIQUE (PD_CO_ID),
    INDEX IDX1_PD_CONTINENT (PD_CO_ID)
   
);

# -----------------------------------------------------------------------
# PD_REGION
# -----------------------------------------------------------------------
drop table if exists PD_REGION;

CREATE TABLE PD_REGION
(
    PD_RG_ID INTEGER NOT NULL,
    PD_RG_NAME_DE VARCHAR (50),
    PD_RG_NAME_EN VARCHAR (50),
    PD_RG_NAME_FR VARCHAR (50),
    PD_RG_NAME_IT VARCHAR (50),
    PD_RG_WWW VARCHAR (60),
    PRIMARY KEY(PD_RG_ID),
    UNIQUE (PD_RG_ID),
    INDEX IDX1_PD_REGION (PD_RG_ID)
   
);

# -----------------------------------------------------------------------
# PD_REGION_CONTINENT
# -----------------------------------------------------------------------
drop table if exists PD_REGION_CONTINENT;

CREATE TABLE PD_REGION_CONTINENT
(
    PD_RG_ID INTEGER NOT NULL,
    PD_CO_ID INTEGER NOT NULL,
    PRIMARY KEY(PD_RG_ID,PD_CO_ID),
    INDEX(PD_CO_ID),
    FOREIGN KEY (PD_CO_ID) REFERENCES PD_CONTINENT (PD_CO_ID),
    FOREIGN KEY (PD_RG_ID) REFERENCES PD_REGION (PD_RG_ID),
    UNIQUE (PD_RG_ID, PD_CO_ID),
    INDEX IDX1_PD_REGION_CONTINENT (PD_RG_ID, PD_CO_ID)
        ,INDEX IDX2_PD_REGION_CONTINENT (PD_RG_ID)
        ,INDEX IDX3_PD_REGION_CONTINENT (PD_CO_ID)
   
);

# -----------------------------------------------------------------------
# PD_COUNTRY
# -----------------------------------------------------------------------
drop table if exists PD_COUNTRY;

CREATE TABLE PD_COUNTRY
(
    PD_CT_ID INTEGER NOT NULL,
    PD_CT_ISO3166_ID INTEGER,
    PD_CT_NAME_DE VARCHAR (50),
    PD_CT_NAME_EN VARCHAR (50),
    PD_CT_NAME_FR VARCHAR (50),
    PD_CT_NAME_IT VARCHAR (50),
    PD_CT_PREPHONE VARCHAR (20),
    PD_CT_2LC VARCHAR (2),
    PD_CT_3LC VARCHAR (3),
    PD_CT_WWW VARCHAR (60),
    PRIMARY KEY(PD_CT_ID),
    UNIQUE (PD_CT_ID),
    INDEX IDX1_PD_COUNTRY (PD_CT_ISO3166_ID)
   
);

# -----------------------------------------------------------------------
# PD_COUNTRY_CONTINENT
# -----------------------------------------------------------------------
drop table if exists PD_COUNTRY_CONTINENT;

CREATE TABLE PD_COUNTRY_CONTINENT
(
    PD_CT_ID INTEGER NOT NULL,
    PD_CO_ID INTEGER NOT NULL,
    PRIMARY KEY(PD_CT_ID,PD_CO_ID),
    INDEX(PD_CO_ID),
    FOREIGN KEY (PD_CO_ID) REFERENCES PD_CONTINENT (PD_CO_ID),
    FOREIGN KEY (PD_CT_ID) REFERENCES PD_COUNTRY (PD_CT_ID),
    UNIQUE (PD_CT_ID, PD_CO_ID),
    INDEX IDX1_PD_COUNTRY_CONTINENT (PD_CT_ID, PD_CO_ID)
        ,INDEX IDX2_PD_COUNTRY_CONTINENT (PD_CT_ID)
        ,INDEX IDX3_PD_COUNTRY_CONTINENT (PD_CO_ID)
   
);

# -----------------------------------------------------------------------
# PD_SUBCOUNTRY
# -----------------------------------------------------------------------
drop table if exists PD_SUBCOUNTRY;

CREATE TABLE PD_SUBCOUNTRY
(
    PD_SUBCT_ID INTEGER NOT NULL,
    PD_CT_ID INTEGER NOT NULL,
    PD_SUBCT_NAME_DE VARCHAR (50),
    PD_SUBCT_NAME_EN VARCHAR (50),
    PD_SUBCT_NAME_FR VARCHAR (50),
    PD_SUBCT_NAME_IT VARCHAR (50),
    PD_SUBCT_PREPHONE VARCHAR (20),
    PD_SUBCT_WWW VARCHAR (60),
    PRIMARY KEY(PD_SUBCT_ID),
    FOREIGN KEY (PD_CT_ID) REFERENCES PD_COUNTRY (PD_CT_ID),
    UNIQUE (PD_SUBCT_ID),
    INDEX IDX1_PD_SUBCOUNTRY (PD_SUBCT_ID)
        ,INDEX IDX2_PD_SUBCOUNTRY (PD_CT_ID)
   
);

# -----------------------------------------------------------------------
# PD_COUNTRY_REGION
# -----------------------------------------------------------------------
drop table if exists PD_COUNTRY_REGION;

CREATE TABLE PD_COUNTRY_REGION
(
    PD_CT_ID INTEGER NOT NULL,
    PD_RG_ID INTEGER NOT NULL,
    PRIMARY KEY(PD_CT_ID,PD_RG_ID),
    INDEX(PD_RG_ID),
    FOREIGN KEY (PD_CT_ID) REFERENCES PD_COUNTRY (PD_CT_ID),
    FOREIGN KEY (PD_RG_ID) REFERENCES PD_REGION (PD_RG_ID),
    UNIQUE (PD_CT_ID, PD_RG_ID),
    INDEX IDX1_PD_COUNTRY_REGION (PD_CT_ID, PD_RG_ID)
        ,INDEX IDX2_PD_COUNTRY_REGION (PD_CT_ID)
        ,INDEX IDX3_PD_COUNTRY_REGION (PD_RG_ID)
   
);

# -----------------------------------------------------------------------
# PD_STOPTYP
# -----------------------------------------------------------------------
drop table if exists PD_STOPTYP;

CREATE TABLE PD_STOPTYP
(
    PD_ST_ID INTEGER NOT NULL,
    PD_ST_DESCR_DE VARCHAR (40),
    PD_ST_DESCR_EN VARCHAR (40),
    PD_ST_DESCR_FR VARCHAR (40),
    PD_ST_DESCR_IT VARCHAR (40),
    PRIMARY KEY(PD_ST_ID),
    UNIQUE (PD_ST_ID),
    INDEX IDX1_PD_STOPTYP (PD_ST_ID)
   
);

# -----------------------------------------------------------------------
# PD_CITY
# -----------------------------------------------------------------------
drop table if exists PD_CITY;

CREATE TABLE PD_CITY
(
    PD_CY_ID INTEGER NOT NULL,
    PD_CT_ID INTEGER NOT NULL,
    PD_SUBCT_ID INTEGER,
    PD_CY_NAME_DE VARCHAR (50),
    PD_CY_NAME_EN VARCHAR (50),
    PD_CY_NAME_FR VARCHAR (50),
    PD_CY_NAME_IT VARCHAR (50),
    PD_CT_PREPHONE VARCHAR (20),
    PD_CT_3LC VARCHAR (3),
    PD_CT_WWW VARCHAR (60),
    PRIMARY KEY(PD_CY_ID),
    FOREIGN KEY (PD_CT_ID) REFERENCES PD_COUNTRY (PD_CT_ID),
    FOREIGN KEY (PD_SUBCT_ID) REFERENCES PD_SUBCOUNTRY (PD_SUBCT_ID),
    UNIQUE (PD_CY_ID),
    INDEX IDX1_PD_CITY (PD_CY_ID)
        ,INDEX IDX2_PD_CITY (PD_CT_ID)
        ,INDEX IDX3_PD_CITY (PD_SUBCT_ID)
   
);

# -----------------------------------------------------------------------
# PD_CITY_CITY_MILES
# -----------------------------------------------------------------------
drop table if exists PD_CITY_CITY_MILES;

CREATE TABLE PD_CITY_CITY_MILES
(
    PD_CC_CITY1 INTEGER NOT NULL,
    PD_CC_CITY2 INTEGER NOT NULL,
    PD_CC_MILES INTEGER NOT NULL,
    PRIMARY KEY(PD_CC_CITY1,PD_CC_CITY2),
    INDEX(PD_CC_CITY2),
    FOREIGN KEY (PD_CC_CITY1) REFERENCES PD_CITY (PD_CY_ID),
    FOREIGN KEY (PD_CC_CITY2) REFERENCES PD_CITY (PD_CY_ID),
    UNIQUE (PD_CC_CITY1, PD_CC_CITY2),
    INDEX IDX1_PD_CITY_CITY_MILES (PD_CC_CITY1, PD_CC_CITY2)
   
);

# -----------------------------------------------------------------------
# PD_AIRPORT
# -----------------------------------------------------------------------
drop table if exists PD_AIRPORT;

CREATE TABLE PD_AIRPORT
(
    PD_AP_ID INTEGER NOT NULL,
    PD_CY_ID INTEGER NOT NULL,
    PD_AP_NAME VARCHAR (60),
    PD_AP_3LC VARCHAR (3),
    PD_AP_CHECKINDESCR_DE VARCHAR (100),
    PD_AP_CHECKINDESCR_EN VARCHAR (100),
    PD_AP_CHECKINDESCR_FR VARCHAR (100),
    PD_AP_CHECKINDESCR_IT VARCHAR (100),
    PD_AP_TAX INTEGER,
    PD_AP_DUTYFREE_ARR INTEGER,
    PD_AP_DUTYFREE_DEP INTEGER,
    PD_AP_FON_CHECKIN VARCHAR (20),
    PD_AP_FON_RESERVATION VARCHAR (20),
    PD_AP_FON_INFO VARCHAR (20),
    PD_AP_WWW VARCHAR (60),
    PRIMARY KEY(PD_AP_ID),
    FOREIGN KEY (PD_CY_ID) REFERENCES PD_CITY (PD_CY_ID),
    UNIQUE (PD_AP_ID),
    INDEX IDX1_PD_AIRPORT (PD_AP_ID)
        ,INDEX IDX2_PD_AIRPORT (PD_CY_ID)
   
);

# -----------------------------------------------------------------------
# PD_AIRCRAFT
# -----------------------------------------------------------------------
drop table if exists PD_AIRCRAFT;

CREATE TABLE PD_AIRCRAFT
(
    PD_AC_ID INTEGER NOT NULL,
    PD_AC_CODE VARCHAR (20),
    PD_AC_NAME VARCHAR (40),
    PD_AC_WINGSPAN INTEGER,
    PD_AC_LENGTH VARCHAR (10),
    PD_AC_HEIGHT INTEGER,
    PD_AC_WINGAREA INTEGER,
    PD_AC_MTOW INTEGER,
    PD_AC_MLW INTEGER,
    PD_AC_MZFW INTEGER,
    PD_AC_ADOW INTEGER,
    PD_AC_EG_CNT INTEGER,
    PD_AC_EN_MODEL VARCHAR (100),
    PD_AC_EN_MANUF VARCHAR (100),
    PD_AC_FUEL_CAP INTEGER,
    PD_AC_SPEED_MAXAIR INTEGER,
    PD_AC_SPEED_CRUISE INTEGER,
    PD_AC_SPEED_CRUISE_MACH INTEGER,
    PD_AC_RANGE_MAX INTEGER,
    PD_AC_CLASS_F_SLUMBERETTES INTEGER,
    PD_AC_CLASS_F INTEGER,
    PD_AC_CLASS_C_MAINDECK INTEGER,
    PD_AC_CLASS_C_UPPERDECK INTEGER,
    PD_AC_CLASS_Y INTEGER,
    PD_AC_CLASS_CY_VARIABLE INTEGER,
    PD_AC_SEAT_CNT INTEGER,
    PD_AC_CARGO_CAPACITY INTEGER,
    PRIMARY KEY(PD_AC_ID),
    UNIQUE (PD_AC_ID),
    INDEX IDX1_PD_AIRCRAFT (PD_AC_ID)
   
);

# -----------------------------------------------------------------------
# PD_AIRLINE
# -----------------------------------------------------------------------
drop table if exists PD_AIRLINE;

CREATE TABLE PD_AIRLINE
(
    PD_AL_ID INTEGER NOT NULL,
    PD_CT_ID INTEGER,
    PD_AL_NAME VARCHAR (60),
    PD_AL_2LC VARCHAR (2),
    PD_AL_3LC VARCHAR (3),
    PD_AL_WWW VARCHAR (60),
    PRIMARY KEY(PD_AL_ID),
    FOREIGN KEY (PD_CT_ID) REFERENCES PD_COUNTRY (PD_CT_ID),
    UNIQUE (PD_AL_ID),
    INDEX IDX1_PD_AIRLINE (PD_AL_ID)
        ,INDEX IDX2_PD_AIRLINE (PD_CT_ID)
        ,INDEX IDX3_PD_AIRLINE (PD_AL_NAME)
   
);

# -----------------------------------------------------------------------
# SYS_LANGUAGE
# -----------------------------------------------------------------------
drop table if exists SYS_LANGUAGE;

CREATE TABLE SYS_LANGUAGE
(
    SYS_LG_CODE VARCHAR (2) NOT NULL,
    SYS_LG_DESCR_DE VARCHAR (100),
    SYS_LG_DESCR_EN VARCHAR (100),
    SYS_LG_DESCR_FR VARCHAR (100),
    SYS_LG_DESCR_IT VARCHAR (100),
    PRIMARY KEY(SYS_LG_CODE),
    UNIQUE (SYS_LG_CODE),
    INDEX IDX1_SYS_LANGUAGE (SYS_LG_CODE)
   
);

# -----------------------------------------------------------------------
# SYS_USER
# -----------------------------------------------------------------------
drop table if exists SYS_USER;

CREATE TABLE SYS_USER
(
    SYS_USER_ID INTEGER NOT NULL,
    PD_CY_ID INTEGER,
    SYS_LG_CODE VARCHAR (2),
    SYS_USER_TID VARCHAR (20),
    SYS_USER_PIN VARCHAR (4),
    SYS_USER_PIN2 VARCHAR (4),
    SYS_USER_PIN_VALID INTEGER,
    SYS_USER_FIRSTNAME VARCHAR (20),
    SYS_USER_LASTTNAME VARCHAR (20),
    SYS_USER_LOGIN VARCHAR (10),
    SYS_USER_PASSWORD VARCHAR (10),
    SYS_USER_FON VARCHAR (20),
    SYS_USER_MOBILE VARCHAR (20),
    SYS_USER_LOCKED INTEGER,
    SYS_USER_VALID_FROM TIMESTAMP,
    SYS_USER_VALID_UNTIL TIMESTAMP,
    PRIMARY KEY(SYS_USER_ID),
    FOREIGN KEY (PD_CY_ID) REFERENCES PD_CITY (PD_CY_ID),
    FOREIGN KEY (SYS_LG_CODE) REFERENCES SYS_LANGUAGE (SYS_LG_CODE),
    UNIQUE (SYS_USER_ID),
    INDEX IDX1_SYS_USER (SYS_USER_ID)
        ,INDEX IDX2_SYS_USER (PD_CY_ID)
        ,INDEX IDX3_SYS_USER (SYS_USER_LOGIN)
        ,INDEX IDX4_SYS_USER (SYS_LG_CODE)
   
);

# -----------------------------------------------------------------------
# SYS_GROUP
# -----------------------------------------------------------------------
drop table if exists SYS_GROUP;

CREATE TABLE SYS_GROUP
(
    SYS_GROUP_ID INTEGER NOT NULL,
    SYS_GROUP_DESCR_DE VARCHAR (40),
    SYS_GROUP_DESCR_EN VARCHAR (40),
    SYS_GROUP_DESCR_FR VARCHAR (40),
    SYS_GROUP_DESCR_IT VARCHAR (40),
    SYS_GROUP_VALID_FROM TIMESTAMP,
    SYS_GROUP_VALID_UNTIL TIMESTAMP,
    PRIMARY KEY(SYS_GROUP_ID),
    UNIQUE (SYS_GROUP_ID),
    INDEX IDX1_SYS_GROUP (SYS_GROUP_ID)
   
);

# -----------------------------------------------------------------------
# USER_GROUP
# -----------------------------------------------------------------------
drop table if exists USER_GROUP;

CREATE TABLE USER_GROUP
(
    SYS_USER_ID INTEGER NOT NULL,
    SYS_GROUP_ID INTEGER NOT NULL,
    PRIMARY KEY(SYS_USER_ID,SYS_GROUP_ID),
    INDEX(SYS_GROUP_ID),
    FOREIGN KEY (SYS_GROUP_ID) REFERENCES SYS_GROUP (SYS_GROUP_ID),
    FOREIGN KEY (SYS_USER_ID) REFERENCES SYS_USER (SYS_USER_ID),
    UNIQUE (SYS_USER_ID, SYS_GROUP_ID),
    INDEX IDX1_USER_GROUP (SYS_USER_ID, SYS_GROUP_ID)
        ,INDEX IDX2_USER_GROUP (SYS_USER_ID)
        ,INDEX IDX3_USER_GROUP (SYS_GROUP_ID)
   
);

# -----------------------------------------------------------------------
# CD_CACHE
# -----------------------------------------------------------------------
drop table if exists CD_CACHE;

CREATE TABLE CD_CACHE
(
    CD_CACHE_SUBJECT VARCHAR (50) NOT NULL,
    CD_CACHE_MESSAGE MEDIUMTEXT,
    CD_CACHE_VALID_FROM TIMESTAMP,
    CD_CACHE_VALID_TO TIMESTAMP,
    PRIMARY KEY(CD_CACHE_SUBJECT),
    INDEX IDX1_CD_CACHE (CD_CACHE_SUBJECT)
   
);

# -----------------------------------------------------------------------
# USER_AIRLINE
# -----------------------------------------------------------------------
drop table if exists USER_AIRLINE;

CREATE TABLE USER_AIRLINE
(
    SYS_USER_ID INTEGER NOT NULL,
    PD_AL_ID INTEGER NOT NULL,
    SYS_UAL_PRIORITY INTEGER,
    PRIMARY KEY(SYS_USER_ID,PD_AL_ID),
    INDEX(PD_AL_ID),
    FOREIGN KEY (SYS_USER_ID) REFERENCES SYS_USER (SYS_USER_ID),
    FOREIGN KEY (PD_AL_ID) REFERENCES PD_AIRLINE (PD_AL_ID),
    UNIQUE (CD_CACHE_SUBJECT),
    UNIQUE (SYS_USER_ID, PD_AL_ID),
    INDEX IDX1_USER_AIRLINE (SYS_USER_ID, PD_AL_ID)
        ,INDEX IDX2_USER_AIRLINE (SYS_USER_ID)
        ,INDEX IDX3_USER_AIRLINE (PD_AL_ID)
   
);

# -----------------------------------------------------------------------
# SYS_FLIGHTGROUP
# -----------------------------------------------------------------------
drop table if exists SYS_FLIGHTGROUP;

CREATE TABLE SYS_FLIGHTGROUP
(
    SYS_FG_ID INTEGER NOT NULL,
    SYS_USER_ID INTEGER NOT NULL,
    SYS_FG_DESCR VARCHAR (100),
    SYS_FG_CITY_ID_SRC INTEGER,
    SYS_FG_CITY_ID_DST INTEGER,
    PRIMARY KEY(SYS_FG_ID,SYS_USER_ID),
    INDEX(SYS_USER_ID),
    FOREIGN KEY (SYS_USER_ID) REFERENCES SYS_USER (SYS_USER_ID),
    UNIQUE (SYS_FG_ID),
    INDEX IDX1_SYS_FLIGHTGROUP (SYS_FG_ID)
        ,INDEX IDX2_IDX1_SYS_FLIGHTGROUP (SYS_USER_ID)
   
);

# -----------------------------------------------------------------------
# AIR_FLIGHT
# -----------------------------------------------------------------------
drop table if exists AIR_FLIGHT;

CREATE TABLE AIR_FLIGHT
(
    AIR_FL_ID INTEGER NOT NULL,
    PD_ST_ID INTEGER NOT NULL,
    AIR_FL_NR_SEG1 INTEGER,
    AIR_FL_NR_SEG2 INTEGER,
    AIR_FL_CITY_ID_SRC INTEGER NOT NULL,
    AIR_FL_CITY_ID_XFER INTEGER,
    AIR_FL_CITY_ID_DST INTEGER NOT NULL,
    AIR_FL_ALC_SEG1 INTEGER,
    AIR_FL_ALC_SEG2 INTEGER,
    AIR_FL_AP_ID_SRC INTEGER,
    AIR_FL_AP_ID_XFER INTEGER,
    AIR_FL_AP_ID_DST INTEGER,
    AIR_FL_TIME_DEP TIME,
    AIR_FL_TIME_XFER_ARR TIME,
    AIR_FL_TIME_XFER_DEP TIME,
    AIR_FL_TIME_ARR TIME,
    AIR_FL_OPS_DAYS VARCHAR (7),
    AIR_FL_STOP_CNT INTEGER,
    AIR_FL_VALID_FROM TIMESTAMP,
    AIR_FL_VALID_UNTIL TIMESTAMP,
    AIR_FL_SERVICE_FLAGS INTEGER,
    PRIMARY KEY(AIR_FL_ID),
    FOREIGN KEY (PD_ST_ID) REFERENCES PD_STOPTYP (PD_ST_ID),
    FOREIGN KEY (AIR_FL_CITY_ID_SRC) REFERENCES PD_CITY (PD_CY_ID),
    FOREIGN KEY (AIR_FL_CITY_ID_XFER) REFERENCES PD_CITY (PD_CY_ID),
    FOREIGN KEY (AIR_FL_CITY_ID_DST) REFERENCES PD_CITY (PD_CY_ID),
    FOREIGN KEY (AIR_FL_ALC_SEG1) REFERENCES PD_AIRLINE (PD_AL_ID),
    FOREIGN KEY (AIR_FL_ALC_SEG2) REFERENCES PD_AIRLINE (PD_AL_ID),
    FOREIGN KEY (AIR_FL_AP_ID_SRC) REFERENCES PD_AIRPORT (PD_AP_ID),
    FOREIGN KEY (AIR_FL_AP_ID_XFER) REFERENCES PD_AIRPORT (PD_AP_ID),
    FOREIGN KEY (AIR_FL_AP_ID_DST) REFERENCES PD_AIRPORT (PD_AP_ID),
    UNIQUE (AIR_FL_ID),
    INDEX IDX1_AIR_FLIGHT (AIR_FL_ID)
        ,INDEX IDX2_AIR_FLIGHT (PD_ST_ID)
        ,INDEX IDX3_AIR_FLIGHT (AIR_FL_ID)
        ,INDEX IDX4_AIR_FLIGHT (AIR_FL_CITY_ID_SRC, AIR_FL_CITY_ID_DST)
   
);

# -----------------------------------------------------------------------
# SYS_FLIGHTGROUP_FLIGHT
# -----------------------------------------------------------------------
drop table if exists SYS_FLIGHTGROUP_FLIGHT;

CREATE TABLE SYS_FLIGHTGROUP_FLIGHT
(
    SYS_FG_ID INTEGER NOT NULL,
    AIR_FL_ID INTEGER NOT NULL,
    SYS_FGF_DATE_FLIGHT TIMESTAMP,
    SYS_FGF_WATCHFLIGHT INTEGER,
    SYS_FGF_REBOOKABLE INTEGER,
    SYS_FGF_VALID_FROM TIMESTAMP,
    SYS_FGF_VALID_UNTIL TIMESTAMP,
    PRIMARY KEY(SYS_FG_ID,AIR_FL_ID),
    INDEX(AIR_FL_ID),
    FOREIGN KEY (AIR_FL_ID) REFERENCES AIR_FLIGHT (AIR_FL_ID),
    FOREIGN KEY (SYS_FG_ID) REFERENCES SYS_FLIGHTGROUP (SYS_FG_ID),
    UNIQUE (SYS_FG_ID, AIR_FL_ID),
    INDEX IDX1_SYS_FLIGHTGROUP_FLIGHT (SYS_FG_ID, AIR_FL_ID)
        ,INDEX IDX2_SYS_FLIGHTGROUP_FLIGHT (SYS_FG_ID)
        ,INDEX IDX3_SYS_FLIGHTGROUP_FLIGHT (AIR_FL_ID)
   
);

# -----------------------------------------------------------------------
# SYS_WTZ
# -----------------------------------------------------------------------
drop table if exists SYS_WTZ;

CREATE TABLE SYS_WTZ
(
    SYS_WTZ_LOCID VARCHAR (10) NOT NULL,
    SYS_WTZ_COUNTRY VARCHAR (50),
    SYS_WTZ_REGION VARCHAR (50),
    SYS_WTZ_CITYLIST VARCHAR (100),
    SYS_WTZ_STDBIAS VARCHAR (20),
    SYS_WTZ_DSTBIAS VARCHAR (20),
    SYS_WTZ_DSTSTARTPATTERN VARCHAR (20),
    SYS_WTZ_DSTENDPATTERN VARCHAR (20),
    SYS_WTZ_MAPFILE VARCHAR (20),
    SYS_WTZ_THISYEARDSTSTART VARCHAR (20),
    SYS_WTZ_THISYEARDSTEND VARCHAR (20),
    SYS_WTZ_NEXTYEARDSTSTART VARCHAR (20),
    SYS_WTZ_NEXTYEARDSTEND VARCHAR (20),
    SYS_WTZ_THISYEARUTCSTART VARCHAR (20),
    SYS_WTZ_THISYEARUTCEND VARCHAR (20),
    SYS_WTZ_NEXTYEARUTCSTART VARCHAR (20),
    SYS_WTZ_NEXTYEARUTCEND VARCHAR (20),
    PRIMARY KEY(SYS_WTZ_LOCID),
    UNIQUE (SYS_WTZ_LOCID),
    INDEX IDX1_SYS_FLIGHTGROUP_FLIGHT (SYS_WTZ_LOCID)
   
);
