
--------------------------------------------------------------------------
-- table1
--------------------------------------------------------------------------
drop table if exists table1;

CREATE TABLE table1
(
    ROWID INTEGER NOT NULL AUTO_INCREMENT,
    NAME VARCHAR (255) NOT NULL,
    SPECIES INTEGER default -2,
    PLANET INTEGER default -1,
    PRIMARY KEY(ROWID)
);
