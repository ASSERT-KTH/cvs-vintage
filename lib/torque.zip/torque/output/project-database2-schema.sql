
--------------------------------------------------------------------------
-- table2
--------------------------------------------------------------------------
drop table if exists table2;

CREATE TABLE table2
(
    ROWID INTEGER NOT NULL AUTO_INCREMENT,
    NAME VARCHAR (255) NOT NULL,
    SPECIES INTEGER default -2,
    PLANET INTEGER default -1,
    PRIMARY KEY(ROWID)
);
