#!/bin/sh
#
# $Id: build.sh,v 1.1 2001/05/13 06:31:29 jvanzyl Exp $
#

# convert the existing path to unix
if [ "$OSTYPE" = "cygwin32" ] || [ "$OSTYPE" = "cygwin" ] ; then
   CLASSPATH=`cygpath --path --unix "$CLASSPATH"`
fi

for i in lib/*.jar
do
    CLASSPATH=${CLASSPATH}:$i
done    

# convert the existing path to windows
if [ "$OSTYPE" = "cygwin32" ] || [ "$OSTYPE" = "cygwin" ] ; then
   CLASSPATH=`cygpath --path --windows "$CLASSPATH"`
fi

# if torque hangs, you may need to boost the memory here
# for example, -Xmx64m will boost the max heap size to 64 megs with sun's vm
${JAVA_HOME}/bin/java -classpath ${CLASSPATH} org.apache.tools.ant.Main "$@"
