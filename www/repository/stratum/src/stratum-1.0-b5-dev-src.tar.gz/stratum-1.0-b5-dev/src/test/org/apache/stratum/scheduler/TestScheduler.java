package org.apache.stratum.scheduler;

/*
 * Copyright (C) The Apache Software Foundation. All rights reserved.
 *
 * This software is published under the terms of the Apache Software License
 * version 1.1, a copy of which has been included with this distribution in
 * the LICENSE file.
 * 
 */

import java.io.File;
import java.io.FileInputStream;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.apache.commons.betwixt.XMLIntrospector;
import org.apache.commons.betwixt.io.BeanReader;
import org.apache.commons.betwixt.strategy.DecapitalizeNameMapper;
import org.apache.commons.betwixt.strategy.DefaultPluralStemmer;
import org.apache.commons.configuration.PropertiesConfiguration;


/**
  * Test harness for the Scheduler
  *
  * @author <a href="mailto:john@zenplex.com">John Thorhauer</a>
  * @version $Id: TestScheduler.java,v 1.3 2004/03/28 17:20:54 epugh Exp $
  */
public class TestScheduler extends TestCase {
    
    private static final String XML  = "src/test-conf/Scheduler.xml";
    private static final String PROPERTIES = 
        "src/test-conf/Scheduler.properties";

    public static void main( String[] args ) {
        TestRunner.run( suite() );
    }
    
    public static Test suite() {
        return new TestSuite(TestScheduler.class);
    }
    
    public TestScheduler(String testName) {
        super(testName);
    }
    
    public void testLoadXmlConfig() throws Exception 
    {
        SchedulerConfig schedConf = new SchedulerConfig();
        FileInputStream in = new FileInputStream(new File(XML));

        // create a new BeanReader
        BeanReader reader = createBeanReader();

        SchedulerConfig schedConf2 = (SchedulerConfig) reader.parse(in);  

        assertNotNull("scheduler should not be null.", schedConf2);
        assertEquals("there should be 2 job configurations", 
                                2, 
                                schedConf2.getJobConfigs().size());
        assertEquals("there should be 2 triggers", 
                                2, 
                                schedConf2.getTriggerConfigs().size());
        assertTrue("scheduler name should be scheduler1",
                        schedConf2.getInstanceName().equals("scheduler1"));

        assertTrue("job name should be job1",
                 ((JobConfig)(schedConf2.getJobConfigs().get(0))).getName().equals("job1"));

    }

    public void testRunScheduler() throws Exception
    {
        Scheduler sched = new Scheduler();
        PropertiesConfiguration conf = new PropertiesConfiguration(PROPERTIES);
        sched.configure(conf);
        
        try 
        {
           sched.start();
           Thread.currentThread().sleep(5000);
           sched.stop();
        }
        catch (InterruptedException e) 
        {
           e.printStackTrace();
        }
 

    }

    // Implementation methods
    //-------------------------------------------------------------------------    
    
    protected BeanReader createBeanReader() throws Exception {
        BeanReader reader = new BeanReader();
        reader.setXMLIntrospector( createXMLIntrospector() );
        reader.registerBeanClass( SchedulerConfig.class );
        return reader;
    }

    /** 
     * ### it would be really nice to move this somewhere shareable across
     * Maven / Turbine projects. Maybe a static helper method - question is
     * what to call it???
     */
    protected XMLIntrospector createXMLIntrospector() {    
        XMLIntrospector introspector = new XMLIntrospector();
        
        // set elements for attributes to true
        introspector.setAttributesForPrimitives(false);
        
        // wrap collections in an XML element
        //introspector.setWrapCollectionsInElement(true);
        
        // turn bean elements first letter into lower case
        introspector.setNameMapper( new DecapitalizeNameMapper() );

        introspector.setPluralStemmer( new DefaultPluralStemmer() );

        return introspector;
    }

}

