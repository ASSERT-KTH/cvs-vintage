package org.apache.stratum.component;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2002 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import junit.framework.Assert;
import org.apache.commons.lang.exception.NestableException;
import org.apache.log4j.Category;
import org.apache.commons.configuration.Configuration;
import org.apache.stratum.lifecycle.Configurable;
import org.apache.stratum.lifecycle.Initializable;

/**
 * This class is used by TestComponentLoader to test some assertions
 * about the behvior of ComponentLoader.
 *
 * @author <a href="mailto:eric NOSPAM dobbse.net">Eric Dobbs</a>
 * @version $Id: MockComponent.java,v 1.3 2002/04/16 20:58:16 kschrader Exp $
 */
public class MockComponent
    extends Assert
    implements Configurable, Initializable
{
    private static Category log = Category.getInstance(MockComponent.class);
    private int callsToConfigure  = 0;
    private int callsToInitialize = 0;
    private int expectedCallsToConfigure  = 1;
    private int expectedCallsToInitialize = 1;

    private Configuration config = null;
    /**
     * Verify that the given Configuration is not null
     * and that configure() is called only once.
     */
    public void configure( Configuration configuration )
        throws NestableException
    {
        log.debug("MockComponent.configure() called");

        config = configuration;

        assertNotNull(configuration);
        log.debug("good news!  configuration not null");

        callsToConfigure++;
        if (callsToConfigure > expectedCallsToConfigure)
        {
            log.debug("bad news!  configure() called too many times");
            fail("configure() called too many times");
        }
        log.debug("good news!  configure() called successfully");
    }

    /**
     * Verify that initialize() is called only once.
     */
    public void initialize()
        throws Exception
    {
        log.debug("MockComponent.initialize() called");

        callsToInitialize++;
        if (callsToInitialize > expectedCallsToInitialize)
        {
            log.debug("bad news!  initialize() called too many times");
            fail("initialize() called too many times");
        }
        log.debug("good news!  initialize() called successfully");
    }

    public Configuration getConfiguration()
    {
        return config;
    }
}
