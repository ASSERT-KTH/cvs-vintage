package org.apache.stratum.component;

import org.apache.commons.configuration.Configuration;

public class AbstractComponent
{
    private Configuration configuration;
    private boolean isConfigured = false;

    public boolean isConfigured()
    {
        return isConfigured;
    }

    public void setConfiguration(Configuration configuration)
    {
        this.configuration = configuration;
        isConfigured = true;
    }

    public Configuration getConfiguration()
    {
        return configuration;
    }
}


