package org.apache.stratum.component;

import org.apache.commons.configuration.Configuration;

public interface Component
{
    boolean isConfigured();
    void setConfiguration(Configuration configuration);
    Configuration getConfiguration();
}    
