package org.apache.stratum.scheduler;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2002 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.PropertiesConfiguration;

import org.apache.log4j.Category;

import org.apache.stratum.lifecycle.Configurable;
import org.apache.stratum.lifecycle.Startable;

import org.apache.commons.betwixt.io.BeanReader;
import org.apache.commons.betwixt.XMLIntrospector;
import org.apache.commons.betwixt.strategy.DecapitalizeNameMapper;
import org.apache.commons.betwixt.strategy.DefaultPluralStemmer;
import org.apache.commons.lang.exception.NestableException;


import org.quartz.SchedulerException;
import org.quartz.JobDetail;
import org.quartz.CronTrigger;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.StdScheduler;

/**
 * This class is the Scheduler component that implements a
 * Quartz scheduler.
 *
 * @author <a href="mailto:john@zenplex.com">John Thorhauer</a>
 * @version $Id: Scheduler.java,v 1.4 2002/08/22 14:07:56 mpoeschl Exp $
 */
public class Scheduler
    implements Configurable, Startable
{

    /**
     * Log4j category used for logging.
     */
    private static Category log = Category.getInstance(Scheduler.class);


    private static String confLocation
            = "/projects/jakarta-turbine-stratum/src/test-conf/Scheduler.properties";
    private StdSchedulerFactory schedulerFactory ;
    protected StdScheduler scheduler;

    /**
     * Just a command line test tool to start the scheduler from
     * the command line.  If looks for the properties file in the
     * following location:<p/>
     * /projects/jakarta-turbine-stratum/src/test-conf/Scheduler.properties
     *
     * @param args command line arguments
     * @throws Exception
     */
    public static void main (String args[]) throws Exception
    {
        Scheduler sched = new Scheduler();
        PropertiesConfiguration conf
                = new PropertiesConfiguration(confLocation);
        sched.configure(conf);
        sched.start();
    }

    /**
     * start the scheduler.
     *
     * @throws Exception
     */
    public void start() throws Exception
    {
        scheduler.start();
    }

    /**
     * stop the scheduler.
     *
     * @throws Exception
     */
    public void stop() throws Exception
    {
        scheduler.shutdown();
    }

    /**
     * Configure the Scheduler
     *
     * @param configuration the configuration
     * @throws NestableException
     */
    public void configure(Configuration configuration) throws NestableException
    {
        String xmlLocation = configuration.getString("scheduler.config.location");

        try
        {
            // get scheduler factory and initialize it with
            // settings from the .xml file
            SchedulerConfig schedConfig = getSchedulerConfig(xmlLocation);
            Properties factoryProps;

            try
            {
                factoryProps = getFactoryProps(schedConfig);
            }
            catch (NullPointerException ex)
            {
                log.error("Error loading properties to initialize" +
                        " Scheduler Factory. Please make sure the following" +
                        " elements are properly filled out in the" +
                        " Scheduler .xml config file:\n" +
                        "   <instanceName></instanceName>\n" +
                        "   <loggerName></loggerName>\n" +
                        "    <threadPoolConfig>\n" +
                        "     <className></className>\n" +
                        "     <threadCount></threadCount>\n" +
                        "     <threadPriority></threadPriority>\n" +
                        "     <loggerName></loggerName>\n" +
                        "   </threadPoolConfig>\n" +
                        "   <jobStoreConfig>\n" +
                        "     <className></className>\n" +
                        "     <loggerName></loggerName>\n" +
                        "   </jobStoreConfig>");
                return;
            }

            schedulerFactory = new StdSchedulerFactory();
            schedulerFactory.initialize(factoryProps);

            scheduler = (StdScheduler) schedulerFactory.getScheduler();

            List jobConfigs = schedConfig.getJobConfigs();

            if (!jobConfigs.isEmpty())
            {
                for (int i = 0; i < jobConfigs.size(); i++)
                {
                    JobConfig jobConf = (JobConfig) jobConfigs.get(i);
                    String jobName = (String) jobConf.getName();

                    String jobPrefix = "scheduler.job." + jobName;
                    String jobGroup = jobConf.getGroup();
                    String jobClassName = jobConf.getClassName();

                    JobDetail job = new JobDetail(jobName, jobGroup,
                                            Class.forName(jobClassName));

                    //get the trigger for this job if it exists
                    TriggerConfig triggerConf
                            = getTriggerConfig(schedConfig, job.getName());
                    if (triggerConf != null)
                    {
                        job.getName();

                        String triggerGroup = triggerConf.getGroup();
                        String triggerName = triggerConf.getName();
                        String cronExpression =
                                        triggerConf.getSeconds() + " " +
                                        triggerConf.getMinutes() + " " +
                                        triggerConf.getHours() + " " +
                                        triggerConf.getDayOfMonth() + " " +
                                        triggerConf.getMonth() + " " +
                                        triggerConf.getDayOfWeek();

                        CronTrigger cronTrigger = new CronTrigger(triggerName,
                                                              triggerGroup,
                                                              jobName,
                                                              jobGroup,
                                                              cronExpression);

                        scheduler.scheduleJob(job, cronTrigger);
                        triggerConf = null;
                        cronTrigger = null;
                    }
                }
            }
        }
        catch (SchedulerException ex)
        {
            log.error("Error Initializing Scheduler:  " + ex.toString(), ex);
        }
        catch (ClassNotFoundException ex)
        {
            log.error("Error Loading class:  " + ex.toString(), ex);
        }
        catch (Exception ex)
        {
            log.error("Error:  " + ex.toString(), ex);
        }
    }

    /**
     * @param schdConf Scheduler Config
     */
    private Properties getFactoryProps(SchedulerConfig schdConf)
    {
        Properties props = new Properties();

        props.put("org.quartz.scheduler.instanceName",
                schdConf.getInstanceName());
        props.put("org.quartz.scheduler.logger", schdConf.getLoggerName());

        // configure loggers
        List loggers = schdConf.getLoggerConfigs();
        for (int i = 0; i < loggers.size(); i++)
        {
            LoggerConfig logger = (LoggerConfig) loggers.get(i);
            String loggerName = "org.quartz.logger." + logger.getName();
            props.put(loggerName + ".class", logger.getClassName());
            props.put(loggerName + ".loggingPriority", logger.getPriority());
            props.put(loggerName + ".outputFile", logger.getOutputFile());

            if (logger.getCategory() != null)
            {
                props.put(loggerName + ".categoryName", logger.getCategory());
            }
        }

        ThreadPoolConfig threadPool = schdConf.getThreadPoolConfig();
        props.put("org.quartz.threadPool.class",
                    threadPool.getClassName());
        props.put("org.quartz.threadPool.threadCount",
                    threadPool.getThreadCount());
        props.put("org.quartz.threadPool.threadPriority",
                    threadPool.getThreadPriority());
        props.put("org.quartz.threadPool.logger",
                    threadPool.getLoggerName());

        JobStoreConfig jobStore = schdConf.getJobStoreConfig();
        props.put("org.quartz.jobStore.class",
                    jobStore.getClassName());
        props.put("org.quartz.jobStore.logger",
                    jobStore.getLoggerName());
        return props;
    }

    /**
     * Loads the SchedulerConfig object from the xml file
     *
     * @param xmlLocation of the xml file
     * @throws Exception
     */
    private SchedulerConfig getSchedulerConfig(String xmlLocation)
            throws Exception
    {
        FileInputStream in = new FileInputStream(xmlLocation);

        // create a new BeanReader
        BeanReader reader = createBeanReader();

        SchedulerConfig schedConf = (SchedulerConfig) reader.parse(in);
        return schedConf;
    }

    /**
     * Creates a beanreader
     *
     * @return beanreader
     * @throws Exception
     */
    private BeanReader createBeanReader() throws Exception
    {
        BeanReader reader = new BeanReader();
        reader.setXMLIntrospector(createXMLIntrospector());
        reader.registerBeanClass(SchedulerConfig.class);
        return reader;
    }

    /**
     * Loads Xml Introspector with needed values
     *
     * @return introspector
     */
    private XMLIntrospector createXMLIntrospector()
    {
        XMLIntrospector introspector = new XMLIntrospector();

        // set elements for attributes to true
        introspector.setAttributesForPrimitives(false);

        // wrap collections in an XML element
        //introspector.setWrapCollectionsInElement(true);

        // turn bean elements first letter into lower case
        introspector.setNameMapper(new DecapitalizeNameMapper());

        introspector.setPluralStemmer(new DefaultPluralStemmer());

        return introspector;
    }


    private TriggerConfig getTriggerConfig(SchedulerConfig schedConf,
                                    String jobName)
    {
        TriggerConfig trig = null;
        List triggers = schedConf.getTriggerConfigs();
        for (int i = 0; i < triggers.size(); i++)
        {
            TriggerConfig tmpTrig = (TriggerConfig) triggers.get(i);
            if (tmpTrig.getJobName().equals(jobName))
            {
                trig = tmpTrig;
                return trig;
            }
        }
        return trig;
    }
}
