package org.apache.stratum.scheduler;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2002 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

//java classes
import java.util.List;
import java.util.ArrayList;

/**
 * This bean represents all of the configuration information
 * needed to load the Quartz scheduler.
 *
 * @author <a href="mailto:john@thorhauer.com">John Thorhauer</a>
 * @version $Id: SchedulerConfig.java,v 1.2 2002/08/22 14:07:56 mpoeschl Exp $
 */
public class SchedulerConfig
{
    /**
     * Scheduler reference name
     */
    private String instanceName;

    /**
     * Scheduler logger name
     */
    private String loggerName;

    /**
     * List of job configurations
     */
    private List jobConfigs;

    /**
     * List of loggers
     */
    private List loggerConfigs;

    /**
     * List of triggers
     */
    private List triggerConfigs;

    /**
     * The jobstore for the Scheduler
     */
    private JobStoreConfig jobStoreConfig;

    /**
     * The threadpool for the Scheduler
     */
    private ThreadPoolConfig threadPoolConfig;

    /**
     * Default contructor
     */
    public SchedulerConfig()
    {
        jobConfigs = new ArrayList();
        loggerConfigs = new ArrayList();
        triggerConfigs = new ArrayList();
    }

    /**
     * Set the reference name given to the scheduler
     * that is loaded into Quartz
     *
     * @param s instanceName
     */
    public void setInstanceName(String s)
    {
        this.instanceName = s;
    }

    /**
     * Return the reference name of the scheduler
     *
     * @return instance name
     */
    public String getInstanceName()
    {
        return this.instanceName;
    }

    /**
     * Set the logger name for the scheduler
     *
     * @param s loggerName
     */
    public void setLoggerName(String s)
    {
        this.loggerName = s;
    }

    /**
     * Return the logger name
     *
     * @return logger name
     */
    public String getLoggerName()
    {
        return this.loggerName;
    }

    /**
     * Add a Job Configuraton to Scheduler Config
     *
     * @param jconf Job configuration
     */
    public void addJobConfig(JobConfig jconf)
    {
        jobConfigs.add(jconf);
    }

    /**
     * Return a list of Job Configurations
     *
     * @return List of job configs
     */
    public List getJobConfigs()
    {
        return this.jobConfigs;
    }

    /**
     * Add a logger Scheduler Config
     *
     * @param logger
     */
    public void addLoggerConfig(LoggerConfig logger)
    {
        loggerConfigs.add(logger);
    }

    /**
     * Return a list of loggers
     *
     * @return List of job configs
     */
    public List getLoggerConfigs()
    {
        return this.loggerConfigs;
    }

    /**
     * Add a trigger to Scheduler Config
     *
     * @param trigger
     */
    public void addTriggerConfig(TriggerConfig trigger)
    {
        triggerConfigs.add(trigger);
    }

    /**
     * Return a list of triggers
     *
     * @return List of triggers
     */
    public List getTriggerConfigs()
    {
        return this.triggerConfigs;
    }

    /**
     * Set the threadPool for the scheduler to use
     *
     * @param thdPool threadPool
     */
    public void setThreadPoolConfig(ThreadPoolConfig thdPool)
    {
        this.threadPoolConfig = thdPool;
    }

    /**
     * Return the the ThreadPool object
     *
     * @return threadPool
     */
    public ThreadPoolConfig getThreadPoolConfig()
    {
        return this.threadPoolConfig;
    }


    /**
     * Set the jobstore for the scheduler to use
     *
     * @param jobStr jobstore
     */
    public void setJobStoreConfig(JobStoreConfig jobStr)
    {
        this.jobStoreConfig = jobStr;
    }

    /**
     * Return the the JobStore object
     *
     * @return jobStore
     */
    public JobStoreConfig getJobStoreConfig()
    {
        return this.jobStoreConfig;
    }
}
