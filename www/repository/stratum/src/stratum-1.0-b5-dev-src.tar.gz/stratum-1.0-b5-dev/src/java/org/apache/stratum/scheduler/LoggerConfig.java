package org.apache.stratum.scheduler;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2002 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */


/**
  * This bean represents the settings used to assign logger
  * properties for use in the Quartz scheduler.
  *
  * @author <a href="mailto:john@zenplex.com">John Thorhauer</a>
  * @version $Id: LoggerConfig.java,v 1.2 2002/08/22 14:07:56 mpoeschl Exp $
  */
public class LoggerConfig
{

    /**
     * The name of the logger.
     */
    private String name;

    /**
     * The classname the is the Quartz logger.
     */
    private String className;

    /**
     * The priority for the logger.
     */
    private String priority;

    /**
     * The output file for the Quartz logger.
     */
    private String outputFile;

    /**
     * The category for the Quartz logger.
     */
    private String category;

    /**
     * Default contructor
     */
    public LoggerConfig()
    {
    }

    /**
     * This is the name of the logger that has will registered with Quartz.
     *
     * @param s logger name
     */
    public void setName(String s)
    {
        this.name = s;
    }

    /**
     * @return the name of the logger
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * This is the full package/class name of the
     * class used for the Quartz logger.
     *
     * @param s the full package/class name used for the logger
     */
    public void setClassName(String s)
    {
        this.className = s;
    }

    /**
     * @return the full package/class name used for the logger
     */
    public String getClassName()
    {
        return this.className;
    }

    /**
     * The priority of the logger
     *
     * @param s priority
     */
    public void setPriority(String s)
    {
        this.priority = s;
    }

    /**
     * @return the priority of the logger
     */
    public String getPriority()
    {
        return this.priority;
    }

    /**
     * The outputFile of the logger
     *
     * @param s outputFile
     */
    public void setOutputFile(String s)
    {
        this.outputFile = s;
    }

    /**
     * @return the outputFile of the logger
     */
    public String getOutputFile()
    {
        return this.outputFile;
    }

    /**
     * The category of the logger
     *
     * @param s category
     */
    public void setCategory(String s)
    {
        this.category = s;
    }

    /**
     * @return the category of the logger
     */
    public String getCategory()
    {
        return this.category;
    }
}
