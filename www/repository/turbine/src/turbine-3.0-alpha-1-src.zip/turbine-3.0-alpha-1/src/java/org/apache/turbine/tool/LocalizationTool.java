package org.apache.turbine.tool;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2003 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;

import org.apache.fulcrum.TurbineServices;
import org.apache.fulcrum.localization.LocalizationService;
import org.apache.turbine.RunData;
import org.apache.turbine.services.pull.ApplicationTool;
import org.apache.turbine.services.yaaficomponent.YaafiComponentService;

/**
 * A pull tool which provides lookups for localized text by delegating
 * to the configured <code>LocalizationService</code>.
 *
 * <p><ul>Enhancement(s) suggested by Daniel Rall and Jacopo
 * Cappellato &lt;jaco@libero.it>:
 *
 * <li><ol>Add Language negotiation overrides the following order
 * <li>user temporary language</li>
 * <li>user permanent language</li>
 * <li>application context language</li>
 * <li>automatic language negotiation (already supported)</li>
 * </ol></li>
 *
 * <li>Missing key message format pulled from TR.props.</li>
 *
 * </ul></p>
 *
 * @author <a href="mailto:dlr@collab.net">Daniel Rall</a>
 * @author <a href="mailto:jon@collab.net">Jon Stevens</a>
 * @author <a href="mailto:leonardr@collab.net">Leonard Richardson</a>
 */
public class LocalizationTool implements ApplicationTool
{
    /**
     * The language and country information parsed from the request's
     * <code>Accept-Language</code> header.  Reset on each request.
     */
    private Locale locale;

    /**
     * The name of the bundle for this tool to use.
     */
    private String bundleName;

    /**
     * The prefix to prepend to localization keys.
     */
    private String keyPrefix;

    /**
     * Creates a new instance.  Used by <code>PullService</code>.
     */
    public LocalizationTool()
    {
    }

    /**
     * <p>Performs text lookups for localization.</p>
     *
     * <p>Assuming there is a instance of this class with a HTTP
     * request set in your template's context named <code>l10n</code>,
     * the VTL <code>$l10n.HELLO</code> would render to
     * <code>hello</code> for English requests and <code>hola</code>
     * in Spanish (depending on the value of the HTTP request's
     * <code>Accept-Language</code> header).</p>
     *
     * @param key The identifier for the localized text to retrieve,
     * prepended by key prefix returned by {@link #getPrefix(String)}
     * (if not <code>null</code>).
     * @return The localized text.
     * @see #get(String, String)
     */
    public String get(String key)
    {
        return get(null, key);
    }

    /**
     * @param prefix A key prefix override which is passed to {@link
     * #getPrefix(String)}.
     * @param key The identifier for the localized text to retrieve,
     * prepended by key prefix (if not <code>null</code>).
     * @return The localized text.
     * @see #get(String)
     */
    public String get(String prefix, String key)
    {
        // Determine prefix, and prepend to key (if necessary).
        key = applyPrefix(prefix, key);

        try
        {
            return getLocalizationService().getString(getBundleName(), getLocale(), key);
        }
        catch (MissingResourceException noKey)
        {
            return formatErrorMessage(key, noKey);
        }
    }

    /**
     * Gets the current locale.
     *
     * @return The locale currently in use.
     */
    public Locale getLocale()
    {
        return locale;
    }

    /**
     * Formats a localized value using the provided object.
     *
     * @param key The identifier for the localized text to retrieve,
     * @param arg1 The object to use as {0} when formatting the localized text.
     * @return Formatted localized text.
     * @see #format(String, List)
     */
    public String format(String key, Object arg1)
    {
        key = applyPrefix(null, key);
        return getLocalizationService().format(getBundleName(), getLocale(), key, arg1);
    }

    /**
     * Formats a localized value using the provided objects.
     *
     * @param key The identifier for the localized text to retrieve,
     * @param arg1 The object to use as {0} when formatting the localized text.
     * @param arg2 The object to use as {1} when formatting the localized text.
     * @return Formatted localized text.
     * @see #format(String, List)
     */
    public String format(String key, Object arg1, Object arg2)
    {
        key = applyPrefix(null, key);
        return getLocalizationService().format(getBundleName(), getLocale(), key,
                                   arg1, arg2);
    }

    /**
     * Formats a localized value using the provided objects.
     *
     * @param key The identifier for the localized text to retrieve,
     * @param args The <code>MessageFormat</code> data used when
     * formatting the localized text.
     * @return Formatted localized text.
     * @see #format(String, List)
     */
    public String format(String key, Object[] args)
    {
        key = applyPrefix(null, key);
        return getLocalizationService().format(getBundleName(), getLocale(), key, args);
    }

    /**
     * <p>Formats a localized value using the provided objects.</p>
     *
     * <p>ResourceBundle:
     * <blockquote><code><pre>
     * VelocityUsersNotWrong={0} out of {1} users can't be wrong!
     * </pre></code></blockquote>
     *
     * Template:
     * <blockquote><code><pre>
     * $l10n.format("VelocityUsersNotWrong", ["9", "10"])
     * </pre></code></blockquote>
     *
     * Result:
     * <blockquote><code><pre>
     * 9 out of 10 Velocity users can't be wrong!
     * </pre></code></blockquote></p>
     *
     * @param key The identifier for the localized text to retrieve,
     * @param args The objects to use as {0}, {1}, etc. when
     *             formatting the localized text.
     * @return Formatted localized text.
     */
    public String format(String key, List args)
    {
        key = applyPrefix(null, key);
        return getLocalizationService().format(getBundleName(), getLocale(), key,
                                   args.toArray());
    }

    /**
     * The return value of this method is used to set the name of the
     * bundle used by this tool.  Useful as a hook for using a
     * different bundle than specifed in your
     * <code>LocalizationService</code> configuration.
     *
     * @param data The inputs passed from {@link #init(Object)}.
     * (ignored by this implementation).
     */
    protected String determineBundleName(Object data)
    {
        return getLocalizationService().getDefaultBundleName();
    }

    /**
     * Returns the name of the bundle currently in use.
     *
     * @param The resource bundle name.
     */
    protected String getBundleName()
    {
        return bundleName;
    }

    /**
     * Returns the prefix prepended to keys used to retrieve localized
     * text.  This method could be overridden to introduce separator
     * text between prefix and key (i.e. <code>prefix__key</code>).
     *
     * @param override Overrides the key prefix set for this instance,
     * or ignored if <code>null</code>.
     * @return The prefix to prepend to localization keys.
     */
    protected String getPrefix(String override)
    {
        return (override == null ? keyPrefix : override);
    }

    /**
     * Appends the current prefix (if any) to the supplied key.
     *
     * @param prefix An override for the current prefix.
     * @param key The key to apply a prefix to.
     * @return The prefixed key, or the same key if no prefix.
     */
    private String applyPrefix(String prefix, String key)
    {
        prefix = getPrefix(prefix);
        if (prefix != null)
        {
            key = prefix + key;
        }
        return key;
    }

    /**
     * Sets the prefix prepended to keys used to retrieve localized
     * text.  Subclasses may wish to call this method in {@link
     * #init(Object)} to auto-negotiate a call to this method (thus
     * automatically setting up the key prefix).
     *
     * @param keyPrefix The prefix to prepend to localization keys, or
     * <code>null</code> for no prefix.
     */
    public void setPrefix(String keyPrefix)
    {
        this.keyPrefix = keyPrefix;
    }

    /**
     * Returns <code>null</code> by default, which causes Velocity to
     * render your reference literally (i.e. <code>$l10n.FooKey</code>
     * will render as exactly that).  Useful as a hook for providing a
     * formatted error message.
     *
     * <p>TODO: Pull alternate error text from a TR.props value, or
     * return <code>null</code> if not available.</p>
     *
     * @param key The name of the key whose attempted retrieval caused
     * an error.
     * @param e The exception thrown when the named key was not
     * available.
     */
    protected String formatErrorMessage(String key, MissingResourceException e)
    {
        return null;
    }


    // ------ ApplicationTool implementation -------------------------------

    /**
     * Sets the request to get the <code>Accept-Language</code> header
     * from (reset on each request).
     */
    public void init(Object data)
    {
        if (data instanceof RunData)
        {
            // Request-scoped initialization.  Pull necessary
            // information out of RunData while we have a reference to
            // it.
            locale = getLocalizationService().getLocale( ((RunData) data).getRequest() );
        }
        bundleName = determineBundleName(data);
    }

    /**
     * Zero everything out.
     */
    public void refresh()
    {
        locale = null;
        bundleName = null;
        setPrefix(null);
    }
    
    /**
     * Utility method for accessing the service implementation
     * 
     * @return a LocalizationService implementation instance
     */
    protected static LocalizationService getLocalizationService() {
        try {
            YaafiComponentService yaafi = (YaafiComponentService) TurbineServices.getInstance().getService(
                    YaafiComponentService.SERVICE_NAME);
            return (LocalizationService) yaafi.lookup(LocalizationService.class.getName());
        } catch (Exception e) {
            throw new RuntimeException("Problem looking up localization service", e);
        }
    }
}
