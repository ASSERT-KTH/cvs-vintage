package org.apache.turbine;

public class TurbineModule
    extends org.apache.turbine.modules.Module
{
}
