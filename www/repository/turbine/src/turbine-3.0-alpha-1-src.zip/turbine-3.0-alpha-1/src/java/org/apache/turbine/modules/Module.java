package org.apache.turbine.modules;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.io.Writer;

import org.apache.fulcrum.ServiceException;
import org.apache.fulcrum.TurbineServices;
import org.apache.fulcrum.template.TemplateService;
import org.apache.turbine.RunData;
import org.apache.turbine.TemplateContext;
import org.apache.turbine.Turbine;
import org.apache.turbine.services.pull.ApplicationTool;
import org.apache.turbine.services.pull.PullService;

/**
 * <p>Responsible for populating contexts (can be thought of as "context
 * builders").  Modules can be aggregated in an arbitrary fashion to
 * render content.</p>
 *
 * <p>Though there is no longer an explict definition of the
 * screen/navigation/layout system used in Turbine 2, this classic
 * model is still a valid usage pattern.  See <a
 * href="http://scarab.tigris.org/">Scarab</a> for an example of an
 * application built using the <code>Module</code> class which follows
 * the classic pattern.</p>
 *
 * @author <a href="mailto:jvanzyl@apache.org">Jason van Zyl</a>
 * @version $Id: Module.java,v 1.9 2004/11/12 10:26:31 epugh Exp $
 */
public class Module
{
    /**
     * A subclass must override this method to build itself.
     * Subclasses override this method to store the layout in RunData
     * or to write the layout to the output stream referenced in
     * RunData.
     *
     * @param data Turbine information.
     * @exception Exception a generic exception.
     */
    protected String doBuild( RunData data )
        throws Exception
    {
        doBuildTemplate(data);
        return "";
    }

    /**
     * Subclasses can override this method to add additional
     * functionality.  This method is protected to force clients to
     * use LayoutLoader to build a Layout.
     *
     * @param data Turbine information.
     * @exception Exception a generic exception.
     */
    protected String build( RunData data )
        throws Exception
    {
        return doBuild( data );
    }

    public String evaluate(RunData data)
        throws Exception
    {
        return doBuild(data);
    }

    public void execute(RunData data)
        throws Exception
    {
        doBuild(data);
    }

    /**
     * This method should be overidden by subclasses that wish to add
     * specific business logic.
     *
     * @param data Turbine information.
     * @exception Exception a generic exception.
     */
    protected void doBuildTemplate( RunData data, TemplateContext context)
        throws Exception
    {
    }

    protected void doBuildTemplate( RunData data )
        throws Exception
    {
        doBuildTemplate(data, getTemplateContext(data));
    }

    /**
     * Populates the TemplateContext with Pull Tools and the
     * RunData object.
     *
     * @param data Turbine information.
     */
    public static TemplateContext getTemplateContext(RunData data)
    {
        // Attempt to get it from the data first.  If it doesn't
        // exist, create it and then stuff it into the data.
        TemplateContext context =
            (TemplateContext) data.getTemp(Turbine.CONTEXT);

        if (context == null)
        {
            context = getPullService().getRuntimeContext(data);
            context.put ( "data", data );
            data.setTemp(Turbine.CONTEXT, context);
        }
        return context;
    }

    public static String handleRequest(TemplateContext context, String template)
        throws ServiceException
    {
        return getTemplateService().handleRequest(new ContextAdapter(context), template);
    }

    public static void handleRequest(TemplateContext context, 
                                       String template, Writer writer)
        throws ServiceException
    {
        getTemplateService().handleRequest(new ContextAdapter(context), 
                                      template, writer);
    }

    public static boolean templateExists(String template)
    {
        return getTemplateService().templateExists(template);
    }

    /**
     * Performs post-request actions (releases context
     * tools back to the object pool).
     *
     * @param context a Velocity Context
     */
    public static void requestFinished(TemplateContext context)
    {
        getPullService().releaseTools(context);
    }

    /**
     * Helper method that allows you to easily get a tool
     * from a Context. Essentially, it just does the cast
     * to an Application tool for you.
     *
     * @param context a Velocity Context to get tools from
     * @param name the name of the tool to get
     * @return ApplicationTool null if no tool could be found
     */
    public static ApplicationTool getTool(TemplateContext context,
                                          String name)
    {
        try
        {
            return (ApplicationTool) context.get(name);
        }
        catch (Exception e)
        {
            return null;
        }
    }

    /**
     * This method is used when you want to short circuit a Screen and
     * change the template that will be executed next. <b>Note that the current
     * context will be applied to the next template that is executed.
     * If you want to have the context executed for the next screen,
     * to be the same one as the next screen, then you should use the
     * TemplateScreen.doRedirect() method.</b>
     *
     * @param data Turbine information.
     * @param template The name of the next template.
     * @deprecated use setTarget(data,template)
     */
    public static void setTemplate(RunData data, String template)
    {
        setTarget(data,template);
    }

    public static void setTarget(RunData data, String template)
    {
        data.setTarget(template);
    }
    
    /**
     * Utility method for accessing the service
     * implementation
     *
     * @return a PullService implementation instance
     */
    protected static PullService getPullService()
    {
        return (PullService)TurbineServices
            .getInstance().getService(PullService.SERVICE_NAME);
    }        

    /**
     * Utility method for accessing the service
     * implementation
     *
     * @return a TemplateService implementation instance
     */
    protected static TemplateService getTemplateService()
    {
        return (TemplateService)TurbineServices
            .getInstance().getService(TemplateService.SERVICE_NAME);
    }  
}
