package org.apache.turbine;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2002 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationFactory;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.http.HttpUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.fulcrum.ServiceManager;
import org.apache.fulcrum.TurbineServices;
import org.apache.log4j.PropertyConfigurator;
import org.apache.turbine.modules.ModuleLoader;
import org.apache.turbine.pipeline.TurbinePipeline;
import org.apache.turbine.services.rundata.RunDataService;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

/**
 * Turbine is the main servlet for the entire system. It is <code>final</code>
 * because you should <i>not</i> ever need to subclass this servlet.  If you
 * need to perform initialization of a service, then you should implement the
 * Services API and let your code be initialized by it.
 * If you need to override something in the <code>doGet()</code> or
 * <code>doPost()</code> methods, edit the TurbineResources.properties file and
 * specify your own classes there.
 *
 * <p> Turbine servlet recognizes the following initialization parameters.
 *
 * <ul>
 * <li><code>properties</code> the path to TurbineResources.properties file
 * used by the default implementation of <code>ResourceService</code>, relative
 * to the application root.</li>
 * <li><code>basedir</code> this parameter is used <strong>only</strong> if your
 * application server does not support web applications, or the or does not
 * support <code>ServletContext.getRealPath(String)</code> method correctly.
 * You can use this parameter to specify the directory within the server's
 * filesystem, that is the base of your web application.</li>
 * </ul><br>
 *
 * If this servlet will always be invoked from another, set the TR.prop
 * turbine.mode = integrated.  If this servlet will operate in a mixed
 * case of standalone and integrated, set turbine.mode = standalone and
 * integrated operation can be specified on a request basis by
 * <code>request.setAttribute("org.apache.turbine.integrated.request.key",
 * Boolean.TRUE);</code> prior to passing control to this servlet.
 *
 * @author <a href="mailto:jon@latchkey.com">Jon S. Stevens</a>
 * @author <a href="mailto:bmclaugh@algx.net">Brett McLaughlin</a>
 * @author <a href="mailto:greg@shwoop.com">Greg Ritter</a>
 * @author <a href="mailto:jmcnally@collab.net">John D. McNally</a>
 * @author <a href="mailto:frank.kim@clearink.com">Frank Y. Kim</a>
 * @author <a href="mailto:krzewski@e-point.pl">Rafal Krzewski</a>
 * @author <a href="mailto:jvanzyl@apache.org">Jason van Zyl</a>
 * @author <a href="mailto:dlr@finemaltcoding.com">Daniel Rall</a>
 * @author <a href="mailto:mpoeschl@marmot.at">Martin Poeschl</a>
 * @version $Id: Turbine.java,v 1.51 2004/11/03 08:56:41 epugh Exp $
 */
public class Turbine
    extends HttpServlet
    implements TurbineConstants
{
    /** Logging class from commons.logging */
    private static Log log = LogFactory.getLog(Turbine.class);

    /**
     * In certain situations the init() method is called more than once,
     * somtimes even concurrently. This causes bad things to happen,
     * so we use this flag to prevent it.
     */
    private static boolean firstInit = true;

    /**
     * Whether init succeeded or not.
     */
    private static Throwable initFailure = null;

    /**
     * Should initialization activities be performed during doGet()
     * execution?
     */
    private static boolean firstDoGet = true;

    /**
     * Turbine application configuration.
     */
    private static Configuration configuration;

    /**
     * This init method will load the default resources from a
     * properties file.
     *
     * @param config typical Servlet initialization parameter.
     * @exception ServletException a servlet exception.
     */
    public final void init(ServletConfig config)
        throws ServletException
    {
        super.init(config);

        synchronized ( this.getClass() )
        {
            if (!firstInit)
            {
                log.warn("Double initializaton of Turbine was attempted!");
                return;
            }
            // executing init will trigger some static initializers, so we have
            // only one chance.
            firstInit = false;

            try
            {
                // Setup static configuration (using default properties file).
                ServletContext context = config.getServletContext();

                configure(config, context);
            }
            catch ( Exception e )
            {
                // save the exception to complain loudly later :-)
                initFailure = e;
                System.err.println(ExceptionUtils.getStackTrace(e));
                log.info("init failed: " + ExceptionUtils.getStackTrace(e));
                return;
            }
            log.info("init complete, Ready to Rumble!");
        }
    }

    /**
     * Initializes the services which need <code>RunData</code> to
     * initialize themselves (post startup).
     *
     * @param data The first <code>GET</code> request.
     */
    public final void init(RunData data)
    {
        synchronized (Turbine.class)
        {
            if (firstDoGet)
            {
                // All we want to do here is save some servlet
                // information so that services and processes
                // that don't have direct access to a RunData
                // object can still know something about
                // the servlet environment.
                saveServletInfo(data);

                // Mark that we're done.
                firstDoGet = false;
            }
        }
    }

    /**
     * The <code>Servlet</code> destroy method.  Invokes
     * <code>ServiceBroker</code> tear down method.
     */
    public final void destroy()
    {
        // Shut down all Turbine Services.
        TurbineServices.getInstance().shutdownServices();
        System.gc();

        // Allow turbine to be started back up again.
        firstInit = true;

        log.info("Done shutting down!");
    }

    /**
     * The primary method invoked when the Turbine servlet is executed.
     *
     * @param req Servlet request.
     * @param res Servlet response.
     * @exception IOException a servlet exception.
     * @exception ServletException a servlet exception.
     */
    public final void doGet (HttpServletRequest req, HttpServletResponse res)
        throws IOException,
               ServletException
    {
        // Placeholder for the RunData object.
        RunData data = null;
        try
        {
            // Check to make sure that we started up properly.
            if (initFailure != null)
            {
                throw initFailure;
            }

            // Get general RunData here...
            // Perform turbine specific initialization below.
            // look for a RunData in the request, in the event this servlet
            // was called from another servlet that already started
            // processing the request
            data = (RunData)req.getAttribute(RUNDATA_REQUEST_KEY);
            if ( data == null )
            {
                data = runDataService.getRunData(req, res, getServletConfig());
            }
            else
            {
                data.setRequest(req);
                data.setResponse(res);
            }


            // If this is the first invocation, perform some
            // initialization.  Certain services need RunData to initialize
            // themselves.
            if (firstDoGet)
            {
                init(data);
            }

            // Stages of Pipeline implementation execution
            // configurable via attached Valve implementations in a
            // XML properties file.
            pipeline.invoke(data);

            /*
            TODO: Move this logic into the pipeline.

            // Handle the case where a module may want to send
            // a redirect.
            if (( data.getStatusCode() == 301 ||
                  data.getStatusCode() ==  302 ) &&
                  data.getRedirectURI() != null )
            {
                data.getResponse().sendRedirect(data.getRedirectURI());
            }
            */
        }
        catch (Throwable t)
        {
            handleException(data, req, res, t);
        }
        finally
        {
            // if the RunData has been added to the request, we assume
            // Turbine is being invoked from another servlet that will
            // handle returning the RunData.
            if ( req.getAttribute(RUNDATA_REQUEST_KEY) == null )
            {
                // Return the used RunData to the factory for recycling.
                runDataService.putRunData(data);
            }
        }
    }

    /**
     * In this application doGet and doPost are the same thing.
     *
     * @param req Servlet request.
     * @param res Servlet response.
     * @exception IOException a servlet exception.
     * @exception ServletException a servlet exception.
     */
    public final void doPost (HttpServletRequest req,
                              HttpServletResponse res)
        throws IOException,
               ServletException
    {
        doGet(req, res);
    }

    /**
     * Return the servlet info.
     *
     * @return a string with the servlet information.
     */
    public final String getServletInfo()
    {
        return "Turbine Servlet @VERSION@";
    }

    /**
     * This method is about making sure that we catch and display
     * errors to the screen in one fashion or another. What happens is
     * that it will attempt to show the error using your user defined
     * Error Screen. If that fails, then it will resort to just
     * displaying the error and logging it all over the place
     * including the servlet engine log file, the Turbine log file and
     * on the screen.
     *
     * @param data A Turbine RunData object.
     * @param req Servlet request.
     * @param res Servlet response.
     * @param t The exception to report.
     */
    private final void handleException(RunData data,
                                       HttpServletRequest req,
                                       HttpServletResponse res,
                                       Throwable t)
        throws ServletException
    {
        // make sure that the stack trace makes it the log
        log.error("handleException: " + t.getMessage(), t);

        try
        {
            exceptionHandler.handleException( data, t );
        }
        catch (ServletException e)
        {
            if ( INTEGRATED.equals(configuration.getString(MODE)) ||
                 req.getAttribute(INTEGRATED_REQUEST_KEY) != null )
            {
                // let the invoking application deal with it
                throw e;
            }
            else
            {
                handleExceptionHandlerException(data, res, e, t);
            }
        }
        catch (Exception f)
        {
            handleExceptionHandlerException(data, res, f, t);
        }
    }

    private void handleExceptionHandlerException(RunData data,
                                                 HttpServletResponse res,
                                                 Exception f,
                                                 Throwable t)
    {
        log.error( "Failed to dispatch to exception handler", f );

        String mimeType = "text/plain";
        try
        {
            // TODO: Make output formatting more flexible --
            // what's below was to remove the use of ECS.
            String trace = ExceptionUtils.getStackTrace(t);
            data.setStackTrace(trace,t);
            res.setContentType(data.getContentType());
            res.setStatus(data.getStatusCode());
            data.getOut().print("<pre>\n" + trace + "\n</pre>");
        }
        // Catch this one because it occurs if some code hasn't been
        // completely re-compiled after a change..
        catch ( java.lang.NoSuchFieldError e )
        {
            try
            {
                res.setContentType( mimeType );
                res.setStatus ( 200 );
            }
            catch (Exception ignored) {}

            try
            {
                data.getOut().print ("java.lang.NoSuchFieldError: " +
                                     "Please recompile all of your " +
                                     "source code.");
            }
            catch (IOException ignored) {}

            log.info ( data.getStackTrace() );
            log.error ( e.getMessage(), e );
        }
        // Attempt to do *something* at this point...
        catch ( Throwable reallyScrewedNow )
        {
            StringBuffer msg = new StringBuffer();
            msg.append("Horrible Exception: ");
            if (data != null)
            {
                msg.append(data.getStackTrace());
            }
            else
            {
                msg.append(t);
            }
            try
            {
                res.setContentType( mimeType );
                res.setStatus ( 200 );
                res.getWriter().print (msg.toString());
            }
            catch (Exception ignored)
            {
            }
            log.error(reallyScrewedNow.getMessage(), reallyScrewedNow);
        }
    }

    // These can probably go into a helper class that
    // the main Turbine class could use. It would probably
    // be wise to build up an contract that is accessible
    // via the Turbine class so that we can try to develop
    // a single point of access for our users. We can
    // slowly start closing off some of our exposed
    // internals.
    //
    // This is information that is collected from
    // the first request. This information is used by
    // services that previously needed to be initialized
    // with a RunData object. These values are in no
    // way meant to be used on a per request basis.
    //
    // There are only a couple of services that needed
    // RunData for initialization but these values are
    // very useful to processes which have no direct
    // access to a RunData object. A scheduled job,
    // for example, might want to process something
    // and place it within the webapp space. Having
    // these values stored here makes this possible.

    /**
     * Server name.
     */
    private static String serverName;

    /**
     * Server port.
     */
    private static String serverPort;

    /**
     * Server scheme.
     */
    private static String serverScheme;

    /**
     * Script name.
     */
    private static String scriptName;

    /**
     * Application root. The base directory for the
     * application. In this case the webapp root in
     * the servlet container.
     */
    private static String applicationRoot;

    /**
     * Servlet config for this Turbine webapp.
     */
    private static ServletConfig servletConfig;

    /**
     * Servlet context for this Turbine webapp.
     */
    private static ServletContext servletContext;

    /**
     * ModuleLoader for this Turbine webapp. Eventually
     * there will be one per app, but we want to
     * move gradually.
     */
    private static ModuleLoader moduleLoader;

    private static Resolver resolver;

    private static ExceptionHandler exceptionHandler;

    private static Pipeline pipeline;

    private static RunDataService runDataService;

    /**
     * A static configuration method that is called by the Turbine servlet
     * or by non-servlet applications for configuring Turbine. It loads
     * the default resources from a properties file.
     *
     * @param config Initialization parameters specific to the Turbine
     * servlet.
     * @param context Servlet container communication channel.
     * Provides access to global initialization parameters.
     * @exception Exception a generic exception.
     */
    public static synchronized void configure(ServletConfig config,
                                              ServletContext context)
        throws Exception
    {
        try
        {
        // Set the application root. This defaults to the webapp
        // context if not otherwise set.
        applicationRoot =
            findInitParameter(context, config, APPLICATION_ROOT, null);

        if (applicationRoot == null || applicationRoot.equals(WEB_CONTEXT))
        {
            applicationRoot = config.getServletContext().getRealPath("");
        }

        // Set the applicationRoot for this webapp.
        setApplicationRoot(applicationRoot);

        // Once we have the application root, we will create
        // any of the directories that are required during
        // runtime. Right now this creates the directories
        // for logging but we might have more of these
        // directories in the future.
        createRuntimeDirectories(context, config);





        // We want to save the ServletConfig and
        // ServletContext so that we can share these objects
        // with parts of Turbine that may need access and
        // have no direct contact with RunData. Right now
        // the ServletService is providing this information,
        // but that service could disappear and client code
        // could use the methods now provided in the Turbine
        // class.
        setTurbineServletConfig(config);
        setTurbineServletContext(context);

        // Get the instance of the service manager
        ServiceManager serviceManager = TurbineServices.getInstance();

        // Set the service managers application root. In our
        // case it is the webapp context.
        serviceManager.setApplicationRoot(getApplicationRoot());


        //
        // Now we run the Turbine configuration code. There are two ways
        // to configure Turbine:
        //
        // a) By supplying an web.xml init parameter called "configuration"
        //
        // <init-param>
        //   <param-name>configuration</param-name>
        //   <param-value>/WEB-INF/conf/turbine.xml</param-value>
        // </init-param>
        //
        // This loads an XML based configuration file.
        //
        // b) By supplying an web.xml init parameter called "properties"
        //
        // <init-param>
        //   <param-name>properties</param-name>
        //   <param-value>/WEB-INF/conf/TurbineResources.properties</param-value>
        // </init-param>
        //
        // This loads a Properties based configuration file. Actually, these are
        // extended properties as provided by commons-configuration
        //
        // If neither a) nor b) is supplied, Turbine will fall back to the
        // known behaviour of loading a properties file called
        // /WEB-INF/conf/TurbineResources.properties relative to the
        // web application root.

        String confFile= findInitParameter(context, config,
                TurbineConfig.CONFIGURATION_PATH_KEY,
                null);

        String confPath;
        String confStyle = "unset";

        if (StringUtils.isNotEmpty(confFile))
        {
            confPath = getRealPath(confFile);
            ConfigurationFactory configurationFactory = new ConfigurationFactory(confPath);
            configurationFactory.setBasePath(getApplicationRoot());
            configuration = configurationFactory.getConfiguration();
            confStyle = "XML";
        }
        else
        {
            confFile = findInitParameter(context, config,
                    TurbineConfig.PROPERTIES_KEY,
            "TurbineResources.properties");

            confPath = getRealPath(confFile);

            // This should eventually be a Configuration
            // interface so that service and app configuration
            // can be stored anywhere.
            configuration = (Configuration) new PropertiesConfiguration(confPath);
            confStyle = "Properties";
        }

        // We want to set a few values in the configuration so
        // that ${variable} interpolation will work for
        //
        // ${applicationRoot}
        // ${webappRoot}
        configuration.setProperty(APPLICATION_ROOT, applicationRoot);
        configuration.setProperty(WEBAPP_ROOT,
            config.getServletContext().getRealPath(""));

//
        // Set up logging as soon as possible
        //
        String log4jFile = configuration.getString(LOG4J_CONFIG_FILE,
                LOG4J_CONFIG_FILE_DEFAULT);

        log4jFile = getRealPath(log4jFile);

        //
        // Load the config file above into a Properties object and
        // fix up the Application root
        //
        Properties p = new Properties();
        try
        {
            p.load(new FileInputStream(log4jFile));
            p.setProperty(APPLICATION_ROOT, getApplicationRoot());
            PropertyConfigurator.configure(p);

            //
            // Rebuild our log object with a configured commons-logging
            log = LogFactory.getLog(Turbine.class.getName());

            log.info("Configured log4j from " + log4jFile);
        }
        catch (FileNotFoundException fnf)
        {
            System.err.println("Could not open Log4J configuration file "
                    + log4jFile + ": ");
            fnf.printStackTrace();
        }

        serviceManager.setConfiguration(configuration);

        // Initialize the service manager. Services
        // that have its 'earlyInit' property set to
        // a value of 'true' will be started when
        // the service manager is initialized.
        serviceManager.init();

        // Set up the module loader for Turbine. Eventually
        // an instance of ModuleLoader will be used for each
        // application running under Turbine but we are trying,
        // for the time being to work in a BC fashion.
        moduleLoader = new ModuleLoader();
        moduleLoader.setConfiguration(configuration);
        moduleLoader.init();

        // set up the resolver, should be done before the pipeline
        String resolverClass;
        resolverClass = configuration.getString(RESOLVER,
                            "org.apache.turbine.pipeline.DefaultResolver");

        log.debug("Using Resolver: " + resolverClass);
        resolver = (Resolver) Class.forName(resolverClass).newInstance();
        resolver.init();

        // Create the error handler

        String exceptionHandlerClass =
            configuration.getString( EXCEPTION_HANDLER,
                "org.apache.turbine.exception.DefaultExceptionHandler" );
        log.debug("Using error handler: " + exceptionHandlerClass);

        exceptionHandler = ( ExceptionHandler )
            Class.forName( exceptionHandlerClass ).newInstance();

        // Set some system properties
        Configuration systemProperties = configuration.subset(SYSTEM);

        if (systemProperties != null)
        {
            for (Iterator k = systemProperties.getKeys(); k.hasNext();)
            {
                String name = (String) k.next();
                String value = systemProperties.getString(name);
                log.debug("System Property: " + name + " => " + value);
                System.getProperties().setProperty(name, value);
            }
        }

        // Setup the default pipeline. There will be a pipeline per
        // (sub)app, just like there will be a module loader per app,
        // but we'll set a standard one up here for now.
        Class pipelineClass = Class.forName
            (configuration.getString("pipeline.default", STANDARD_PIPELINE));

        log.debug("Using Pipeline: " + pipelineClass.getName());
        if (TurbinePipeline.class.isAssignableFrom(pipelineClass))
        {
            // Turbine's standard Pipeline implementation uses
            // descriptors to define what Valves are attached to it.
			Reader reader =null;
            String descriptorPath = configuration.getString(
                "pipeline.default.descriptor", TurbinePipeline.CLASSIC_PIPELINE);
			InputStream inputStream = Turbine.class.getClassLoader().getResourceAsStream(descriptorPath);
			if(inputStream != null)
			{
				reader = new BufferedReader(new InputStreamReader(inputStream));
			}
			else
			{
                descriptorPath = getRealPath(descriptorPath);
                reader = new BufferedReader(new FileReader(descriptorPath));
			}
			log.debug("Using descriptor path: " + descriptorPath);
            XStream pipelineMapper = new XStream(new DomDriver()); // does not require XPP3 library
            pipeline = (Pipeline) pipelineMapper.fromXML(reader);
        }
        else
        {
            // Other Pipeline implementations are assumed to choose
            // the Valves that they attach in another fashion (such as
            // by hard-coding them).
            pipeline = (Pipeline) pipelineClass.newInstance();
        }

        log.debug("Initializing pipeline");
        pipeline.initialize();

        log.debug("Getting rundataservice: ");
        // Setup the RunData service for the application
        runDataService = (RunDataService) TurbineServices.getInstance()
            .getService(RunDataService.SERVICE_NAME);
        log.debug("RunDataService: " + runDataService);
        }
        catch (Throwable e)
        {
            e.printStackTrace();
            log.error(e);
            throw new TurbineException(e);
        }
    }

    /**
     * Create any directories that might be needed during
     * runtime. Right now this includes:
     *
     * <ul>
     *
     * <li>The directory to write the log files to (relative to the
     * web application root), or <code>null</code> for the default of
     * <code>/logs</code>.  The directory is specified via the {@link
     * TurbineConstants#LOGGING_ROOT} parameter.</li>
     *
     * </ul>
     *
     * @param context Global initialization parameters.
     * @param config Initialization parameters specific to the Turbine
     * servlet.
     */
    private static void createRuntimeDirectories(ServletContext context,
                                                 ServletConfig config)
    {
        String path = findInitParameter(context, config, LOGGING_ROOT, "/logs");
        File logDir = new File(getRealPath(path));
        if (!logDir.exists())
        {
            // Create the logging directory
            if (!logDir.mkdirs())
            {
                System.err.println("Cannot create directory for logs!");
            }
        }
    }

    /**
     * Finds the specified servlet configuration/initialization
     * parameter, looking first for a servlet-specific parameter, then
     * for a global parameter, and using the provided default if not
     * found.
     */
    protected static final String findInitParameter(ServletContext context,
                                                    ServletConfig config,
                                                    String name,
                                                    String defaultValue)
    {
        String path = null;

        // Try the name as provided first.
        boolean usingNamespace = name.startsWith(CONFIG_NAMESPACE);
        while (true)
        {
            path = config.getInitParameter(name);
            if (StringUtils.isEmpty(path))
            {
                path = context.getInitParameter(name);
                if (StringUtils.isEmpty(path))
                {
                    // The named parameter didn't yield a value.
                    if (usingNamespace)
                    {
                        path = defaultValue;
                    }
                    else
                    {
                        // Try again using Turbine's namespace.
                        name = CONFIG_NAMESPACE + '.' + name;
                        usingNamespace = true;
                        continue;
                    }
                }
            }
            break;
        }

        return path;
    }

    /**
     * Get the ModuleLoader for this Turbine webapp.
     * Eventually we will want to be able to grab a ModuleLoader
     * by app name, or app identifier.
     *
     * @return ModuleLoader
     */
    public static ModuleLoader getModuleLoader()
    {
        return moduleLoader;
    }

    /**
     * Get the Resolver for this Turbine webapp.
     * @return Resolver
     */
    public static Resolver getResolver()
    {
        return resolver;
    }

    /**
     * Save some information about this servlet so that
     * it can be utilized by object instances that do not
     * have direct access to RunData.
     *
     * @param data
     */
    public static synchronized void saveServletInfo(RunData data)
    {
        serverName = data.getRequest().getServerName();
        serverPort = new Integer(data.getRequest().getServerPort()).toString();
        serverScheme = data.getRequest().getScheme();
        scriptName = applicationRoot + data.getRequest().getServletPath();
    }

    /**
     * Set the application root for the webapp.
     *
     * @param val New app root.
     */
    public static void setApplicationRoot(String val)
    {
        applicationRoot = val;
    }

    /**
     * Get the application root.
     *
     * @return String app root.
     */
    public static String getApplicationRoot()
    {
        return applicationRoot;
    }

    /**
     * Get the expanded path relative to the app root.
     *
     * @param path Relative path to translate.
     */
    public static String getRealPath(String path)
    {
        return getApplicationRoot() + '/' + path;
    }

    /**
     * Get the server name.
     *
     * @return String server name.
     */
    public static String getServerName()
    {
        return serverName;
    }

    /**
     * Get the server port.
     *
     * @return String server port.
     */
    public static String getServerPort()
    {
        return serverPort;
    }

    /**
     * Get the server scheme.
     *
     * @return String server scheme.
     */
    public static String getServerScheme()
    {
        return serverScheme;
    }

    /**
     * Get the script name. This is the initial script name.
     * Actually this is probably not needed any more. I'll
     * check. jvz.
     *
     * @return String initial script name.
     */
    public static String getScriptName()
    {
        return scriptName;
    }

    /**
     * Set the servlet config for this turbine webapp.
     *
     * @param s New servlet config
     */
    public static void setTurbineServletConfig(ServletConfig s)
    {
        servletConfig = s;
    }

    /**
     * Get the servlet config for this turbine webapp.
     *
     * @return ServletConfig
     */
    public static ServletConfig getTurbineServletConfig()
    {
        return servletConfig;
    }

    /**
     * Set the servlet context for this turbine webapp.
     *
     * @param s New servlet context.
     */
    public static void setTurbineServletContext(ServletContext s)
    {
        servletContext = s;
    }

    /**
     * Get the servlet context for this turbine webapp.
     *
     * @return ServletContext
     */
    public static ServletContext getTurbineServletContext()
    {
        return servletContext;
    }

    /**
     * Get the configuration for this turbine webapp.
     *
     * @return Turbine configuration.
     */
    public static Configuration getConfiguration()
    {
        return configuration;
    }

    /**
     * This method sets the required expiration headers in the response
     * for a given RunData object.  This method attempts to set all
     * relevant headers, both for HTTP 1.0 and HTTP 1.1.
     *
     * @param data The RunData object we are setting cache information for.
     * @param expiry The number of seconds untill the document should expire,
     * <code>0</code> indicating immediate expiration (i.e. no caching).
     */
    public static void setCacheHeaders(RunData data, int expiry)
    {
        if ( expiry == 0 )
        {
            data.getResponse().setHeader("Pragma", "no-cache");
            data.getResponse().setHeader("Cache-Control", "no-cache");
            data.getResponse().setHeader(
                    "Expires", HttpUtils.formatHttpDate(new Date()));
        }
        else
        {
            Date expiryDate = new Date( System.currentTimeMillis() + expiry );
            data.getResponse().setHeader(
                    "Expires", HttpUtils.formatHttpDate(expiryDate));
        }
    }
}
