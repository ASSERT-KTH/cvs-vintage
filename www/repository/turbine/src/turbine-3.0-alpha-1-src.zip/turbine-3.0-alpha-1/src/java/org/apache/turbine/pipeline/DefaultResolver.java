package org.apache.turbine.pipeline;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import org.apache.turbine.Turbine;
import org.apache.turbine.TurbineConstants;
import org.apache.turbine.Resolver;
import org.apache.turbine.modules.Module;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

// Renderers and context builders
// We need to match up the target template with sibling
// templates and context builders for each of these templates.

// Given a target template

// 1. find all possible classes that could be used
//    as context builders
// 2. find all possible sibling templates that could
//    be used with the target template

// We are using the classic turbine method of using
// a screen template.

// Say we have a base template of:
//
// /base/science/chemistry/Titanium.vm
//
// 1. We want to find the context builder to this
// target template if there is one, there won't
// be if we're using pull.
//
// 2. Find the layout/nav templates to use and find
//    their context builders.

/**
 * Resolver that finds the appropriate context populator
 * and sibling templates for a given target template.
 *
 * This is the 2.1 algorithm used to find a context populator
 * (or module in 2.1 parlance), sibling templates and their
 * context populators.
 *
 * This algorithm or strategy should be pluggable. For example
 * using a different resolver would allow search for templates
 * to occur in a localized manner possibly even for content
 * type. Right now there is some code in Jetspeed called the
 * profiler that David Taylor is working on and it would probably
 * be good to turn that into a resolver so that the functionality
 * is available in Turbine. There is also the Resources code in
 * the commons which we can also leverage and that code can now
 * deal with localization issues it appears. Would be good to
 * take a look at all this code and pull the best out so that
 * it can be placed in Turbine proper. The first task is to
 * get a simple resolver working for the 'classic' pipeline.
 * More flexibility in terms of configuration with XML can
 * come in a while.
 */

/*
   NOTE:  Currently the ModuleLoader handles a lot of the responsiblity
   for finding, caching, and serving up modules.  That functionaly
   should be placed in the pluggable resolver.  I'll leave it for now so
   to make the changes more gradually.

   subclasses can override findTemplate and findModule to 
   use a different algorithm, while using the caching mechanism
   of the DefaultResolver

   subclasses should override getTemplate and getModule if they
   wish to use a different caching mechanism

*/

/**
 * This class is used to find templates and modules
 *
 * @author <a href="mailto:jvanzyl@apache.org">Jason van Zyl</a>
 * @author <a href="mailto:mikeh@apache.org">Mike Haberman</a>
 * @version $Id: DefaultResolver.java,v 1.16 2002/04/09 17:29:34 jtaylor Exp $
 */
public class DefaultResolver
    implements Resolver, TurbineConstants
{
    private static final Log log = LogFactory.getLog(DefaultResolver.class);
    
    protected String defaultTemplate;

    public void init()
        throws Exception
    {
        defaultTemplate = 
            Turbine.getConfiguration().getString("template.default") + 
            "." +
            Turbine.getConfiguration().getString("template.default.extension");

        // insist that the default template starts with a '/'
        int idx = defaultTemplate.indexOf('/');
        if (idx == -1 || idx > 0)
        {
            defaultTemplate = "/" + defaultTemplate;
        }

        log.debug("DefaultResolver: default template " + defaultTemplate);
    }

    /**
     * Get the qualified template name
     * Used for resolving top level rendering process.
     * For turbine classic edition, 
     * moduleType is one of (layouts, screens, navigations)
     */
    public String getTemplate(String moduleType, String targetTemplate)
        throws Exception
    {
        return findTemplate(moduleType, targetTemplate);
    }

    /**
     * Get an instance of a module
     *
     * For turbine classic edition, type is one of (actions, screens) 
     * @param type
     * @param name
     * @return
     */
    public Module getModule(String type, String name)
        throws Exception
    {
        return findModule(type, name);
    }

    protected String findTemplate(String moduleType, String targetTemplate)
        throws Exception
    {
        StringBuffer sb = new StringBuffer();
        PipelineUtil.parseTemplatePath(targetTemplate, sb);
        Iterator j = getPossibleTemplates(sb.toString());

        while (j.hasNext())
        {
            String template = moduleType + "/" + (String) j.next();
            if (Module.templateExists(template))
            {
                return template;
            }
        }

        // We should have a default template type for
        // each corresponding module and a default extension.
        return moduleType + defaultTemplate;
    }
    
    /**
     * Get the parsed module name for the specified template.
     *
     * @param template The template name.
     * @return The parsed module name.
     * @exception Exception a generic exception.
     */
    protected Iterator getPossibleTemplates(String template)
        throws Exception
    {
        List packages = new ArrayList();

        // Parse the template name and change it into a package.
        StringBuffer pckage = new StringBuffer();
        int i = PipelineUtil.parseTemplatePath(template,pckage);

        if (pckage.charAt(0) == '/')
        {
            pckage.deleteCharAt(0);
            i--;
        }

        String extension = Turbine.getConfiguration()
            .getString("template.default.extension", "vm");

        // Try first an exact match for a module having the same
        // name as the input template, traverse then upper level
        // packages to find a default module named Default.
        int j = 9999;
        String module;
        while (j-- > 0)
        {
            module = pckage.toString();

            packages.add(module);

            pckage.setLength(i + 1);
            if (i > 0)
            {
                // We have still packages to traverse.
                for (i = pckage.length() - 2; i >= 0; i--)
                {
                    if (pckage.charAt(i) == '/')
                    {
                        break;
                    }
                }
            }
            else if (j > 0)
            {
                // Only the main level left.
                j = 1;
            }
            pckage.append("Default").append(".").append(extension);
        }

        // Not found, return the default module name.
        return packages.iterator();
    }

    protected Module findModule(String type, String name)
        throws Exception
    {
        // just use the module loader's default algorithm
        // perhaps that code should be put here 
        return Turbine.getModuleLoader().getModule(type,name);
    }
}
