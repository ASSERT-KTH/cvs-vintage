package org.apache.turbine.modules;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2002 The Apache Software Foundation. All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.FastArrayList;
import org.apache.commons.collections.FastHashMap;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.turbine.Turbine;
import org.apache.turbine.TurbineException;
import org.apache.turbine.pipeline.PipelineUtil;

/**
 * Load modules for use in the view pipeline.
 *
 * @author <a href="mailto:jvanzyl@apache.org">Jason van Zyl</a>
 * @author <a href="mailto:mpoeschl@marmot.at">Martin Poeschl</a>
 * @version $Id: ModuleLoader.java,v 1.12 2004/01/31 01:34:50 epugh Exp $
 */
public class ModuleLoader
{
    private static final Log log = LogFactory.getLog( ModuleLoader.class );
    /**
     * Module packages for this module loader.
     */
    protected List modulePackages;

    /**
     * A String representation of the module packages
     * that are search. Used in exception handling.
     */
    protected StringBuffer modulePackagesNames;

    /**
     * The default module to load when nothing else
     * can be found.
     */
    protected String defaultModule;

    /**
     * The defaults modules for the various defined types.
     */
    protected Map defaultModules;

    /**
     * Property that controls whether scripting is enabled
     * for this module loader.
     */
    protected boolean scriptingEnabled;

    protected Configuration configuration;

    /**
     * Default constructor.
     */
    public ModuleLoader()
    {
        modulePackages = new FastArrayList();
        modulePackagesNames = new StringBuffer();
        defaultModules = new FastHashMap();
    }

    /**
     * Add a module package to the search list.
     *
     * @param modulePackage module package to add to search list
     */
    public void addModulePackage(String modulePackage)
    {
        modulePackages.add(modulePackage);
        modulePackagesNames.append(modulePackage).append("\n");
    }


    /**
     * Set the configuration for the module loader
     */
    public void setConfiguration(Configuration configuration)
    {
        this.configuration = configuration;
    }

    /**
     * Initialize this module loader.
     */
    public void init()
        throws TurbineException
    {
        Configuration moduleTypes = configuration.subset("module.default");

        if (moduleTypes == null)
        {
            throw new TurbineException(
                "module.default subset is missing from TR.props");
        }

        Iterator j = moduleTypes.getKeys();

        while (j.hasNext())
        {
            String moduleType = (String) j.next();
            String defaultModule = moduleTypes.getString(moduleType);

            // Add the default module for the particular
            // module type to our container for module defaults.
            setDefaultModule(moduleType, defaultModule);
        }

        // Grab our list of module packages so that we can
        // add them to the search list of the ModuleLoader.
        List modulePackages = configuration.getList(Turbine.MODULE_PACKAGES);

        Iterator i = modulePackages.iterator();

        while (i.hasNext())
        {
            addModulePackage((String) i.next());
        }

        // Add the package for Turbine's default modules.
        // This package must be added last so it is searched
        // for last.
        addModulePackage(Turbine.DEFAULT_MODULE_PACKAGE);
    }

    /**
     * Get an instance of a module
     *
     * All clients should use Turbine.getResolver().getModule(type,name)
     * to get the module.  The only client of ModuleLoader.getModule(type,name)
     * should be the resolver.
     *
     * @param name
     * @param type
     * @return The desired <code>Module</code>, or <code>null</code>
     * if not found..
     */
    public Module getModule(String type, String name)
        throws Exception
    {
        Module module = null;

        Iterator k;
        if (type.equals("actions"))
        {
            k = getAllPossibleActions(name);
        }
        else
        {
            StringBuffer sb = new StringBuffer();
            PipelineUtil.parseTemplatePath(name, sb);
            List names = getPossibleModules(sb.toString());
            k = getAllPossibleModules(names, type);
        }

        while (k.hasNext())
        {
            String moduleClass = (String) k.next();

            try
            {
                log.debug("Looking for " + moduleClass);
                module = (Module) Class.forName(moduleClass).newInstance();
                log.debug("Mapped " + name + " to " + moduleClass);
                break;
            }
            catch (Exception ignored)
            {
                // Likely a non-existant class name combination.
            }
        }

        if (module == null)
        {
            throw new Exception(
                "Can't find module for " + name + " in " + modulePackagesNames);
        }

        return module;
    }

    /**
     * Returns the cross product of module packages, names, and type.
     *
     * @param names Possible modules for a specific template.
     * @param type The type modules to generate possibile fully
     * qualified class names for.
     */
    private Iterator getAllPossibleModules(List names, String type)
    {
        FastArrayList modules = new FastArrayList();
        FastArrayList defaultModules = new FastArrayList();

        Iterator i = modulePackages.iterator();
        while (i.hasNext())
        {
            String modulePackage = (String) i.next();
            Iterator m = (Iterator) names.iterator();
            while (m.hasNext())
            {
                String module = modulePackage + "." + type + "." + m.next();
                modules.add(module);

            }

            // Add default for type
            defaultModules.add(modulePackage + "." + getDefaultModule(type));
        }

        modules.addAll(defaultModules);

        return modules.iterator();
    }

    /**
     * @param name The name of the <code>Action</code> to retrieve
     * class names for.
     */
    private Iterator getAllPossibleActions(String name)
    {
        FastArrayList actions = new FastArrayList();

        Iterator i = modulePackages.iterator();
        while (i.hasNext())
        {
            String action = (String) i.next() + ".actions." + name;
            actions.add(action);
        }

        return actions.iterator();
    }

    /**
     * Set the default module to load when no other module
     * can be found.
     */
    public void setDefaultModule(String defaultModule)
    {
        this.defaultModule = defaultModule;
    }

    /**
     * Set the default module for a type.
     */
    public void setDefaultModule(String type, String defaultModule)
    {
        defaultModules.put(type, defaultModule);
    }

    /**
     * "New module stuff"
     */
    public String getDefaultModule(String moduleType)
    {
        return (String) defaultModules.get(moduleType);
    }

    /**
     * Set whether or not this module loader will attempt
     * to find BSF script to execute in the place of
     * java classes.
     */
    public void setScriptingEnabled(boolean state)
    {
        scriptingEnabled = state;
    }

    /**
     *
     *
     * @param template
     * @return
     */
     protected List getPossibleModules(String template)
        throws Exception
    {
        List packages = new FastArrayList();

        // Parse the template name and change it into a package.
        StringBuffer pckage = new StringBuffer();
        int i = PipelineUtil.parseTemplatePath(template,pckage);

        if (pckage.charAt(0) == '/')
        {
            pckage.deleteCharAt(0);
            i--;
        }

        if (i >= 0)
        {
            for (int j = 0; j <= i; j++)
            {
                if (pckage.charAt(j) == '/')
                {
                    pckage.setCharAt(j, '.');
                }
            }
        }

        // Remove a possible file extension.
        for (int j = i + 1; j < pckage.length(); j++)
        {
            if (pckage.charAt(j) == '.')
            {
                pckage.delete(j,pckage.length());
                break;
            }
        }

        // Try first an exact match for a module having the same
        // name as the input template, traverse then upper level
        // packages to find a default module named Default.
        int j = 9999;
        String module;
        while (j-- > 0)
        {
            module = pckage.toString();

            packages.add(module);

            pckage.setLength(i + 1);
            if (i > 0)
            {
                // We have still packages to traverse.
                for (i = pckage.length() - 2; i >= 0; i--)
                {
                    if (pckage.charAt(i) == '.')
                    {
                        break;
                    }
                }
            }
            else if (j > 0)
            {
                // Only the main level left.
                j = 1;
            }
            pckage.append("Default");
        }

        // Not found, return the default module name.
        return packages;
    }
}
