package org.apache.turbine.pipeline;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2003 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.io.IOException;

import org.apache.turbine.Pipeline;
import org.apache.turbine.RunData;
import org.apache.turbine.TurbineException;
import org.apache.turbine.ValveContext;

/**
 * A {@link org.apache.turbine.Valve} description of a pipeline's
 * branch point.  It may itself be the start of zero or more {@link
 * org.apache.turbine.Pipeline} paths, and can even continue executing
 * the pipeline that the branch point resides on after its branch
 * pipelines finish.
 *
 * @author <a href="mailto:dlr@finemaltcoding.com">Daniel Rall</a>
 * @version $Id: BranchPointValve.java,v 1.7 2003/11/23 00:42:22 mpoeschl Exp $
 */
public abstract class BranchPointValve
    extends AbstractValve
{
    /**
     * A constant indicating no sub-pipelines.
     */
    protected static final Pipeline[] NO_PIPELINES = new Pipeline[0];

    /**
     * Sub-pipelines which we may branch process off into.
     */
    protected Pipeline[] pipelines = NO_PIPELINES;

    /**
     * Initializes all sub-pipelines.
     *
     * @see org.apache.turbine.Valve#initialize
     */
    public void initialize()
        throws Exception
    {
        if (pipelines != NO_PIPELINES)
        {
            for (int i = 0; i < pipelines.length; i++)
            {
                pipelines[i].initialize();
            }
        }
    }

    /**
     * <p>Selects which pipeline path to branch down.  This may just
     * consist of calling <code>context.invokeNext(data)</code> to
     * continue down the current pipeline's path.  The desired branch
     * path is generally determined using data pulled from the
     * supplied<code>RunData</code>.</p>
     *
     * <p>Here's an illustration of inserting a
     * <code>BranchPointValve</code> into the
     * <code>TurbinePipeline</code> processing sequence:
     *
     * <blockquote><pre>
     *                                         ___ (start of FooPipeline)
     *                                        /
     * ---[Valve]--[Valve]--[BranchPointValve]---- (continue w/ TurbinePipeline)
     *                                        \
     *                                         --- (start of BarPipeline)
     * </pre></blockquote>
     *
     * The <code>BranchPointValve</code> could just as easily stop all
     * processing by neither invoking a new pipeline nor calling
     * <code>invokeNext()</code>.
     * </p>
     *
     * @param data The run-time data.
     * @exception IOException Problem choosing pipeline to branch down.
     * @exception TurbineException Problem choosing pipeline to branch down.
     * @see org.apache.turbine.Valve#invoke(RunData, ValveContext)
     */
    public abstract void invoke(RunData data, ValveContext context)
        throws IOException, TurbineException;
}
