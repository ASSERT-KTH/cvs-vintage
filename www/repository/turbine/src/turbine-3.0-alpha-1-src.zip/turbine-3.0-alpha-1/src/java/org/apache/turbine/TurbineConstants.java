package org.apache.turbine;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import org.apache.turbine.pipeline.TurbinePipeline;

/**
 * This interface contains all the constants used throughout
 * the Turbine code base.
 *
 * @author <a href="mailto:jvanzyl@apache.org">Jason van Zyl</a>
 */
public interface TurbineConstants
{
    /**
     * <p>The prefix used to denote the namespace reserved for and
     * used by Turbine-specific configuration parameters (such as
     * those passed in via servlet container's config file
     * (<code>server.xml</code>), or the web app deployment descriptor
     * (<code>web.xml</code>).</p>
     *
     * <p>For example, a parameter in the Turbine namespace would be
     * <code>org.apache.turbine.loggingRoot</code>.</p>
     */
    public static final String CONFIG_NAMESPACE = "org.apache.turbine";

    /**
     * The logging facility which captures output from Peers.
     */
    public static final String SQL_LOG_FACILITY = "sql";

    /**
     * The logging facility which captures output from the SchedulerService.
     */
    public static final String SCHEDULER_LOG_FACILITY = "scheduler";

    /**
     * SMTP server Turbine uses to send mail.
     */
    public static final String MAIL_SERVER_KEY = "mail.server";

    /**
     * The size of the actions cache if module caching is on.
     */
    public static final String ACTION_CACHE_SIZE = "action.cache.size";

    /**
     * The size of the layout cache if module caching is on.
     */
    public static final String LAYOUT_CACHE_SIZE = "layout.cache.size";

    /**
     * The size of the navigation cache if module caching is on.
     */
    public static final String NAVIGATION_CACHE_SIZE = "navigation.cache.size";

    /**
     * The size of the actions page if module caching is on.
     */
    public static final String PAGE_CACHE_SIZE = "page.cache.size";

    /**
     * The size of the actions cache if module caching is on.
     */
    public static final String SCREEN_CACHE_SIZE = "screen.cache.size";

    /**
     * The size of the actions cache if module caching is on.
     */
    public static final String SCHEDULED_JOB_CACHE_SIZE =
        "scheduledjob.cache.size";

    /**
     * The fully qualified class name of the default {@link
     * org.apache.turbine.Pipeline} implementation to use in the
     * {@link org.apache.turbine.Turbine} servlet.
     */
    public static final String STANDARD_PIPELINE =
        TurbinePipeline.class.getName();

    /**
     * The packages where Turbine will look for modules.
     * This is effectively Turbine's classpath.
     */
    public static final String MODULE_PACKAGES = "module.packages";

    /**
     * Configuration key for the ExceptionHandler that Turbine will use.
     */
    public static final String EXCEPTION_HANDLER = "exceptionHandler.default";

    /**
     * what resolver Turbine will use
     */
    public static final String RESOLVER = "resolver.default";

    /**
     * what will the resolver cache (replaces the <module.cache> property)
     */
    public static final String RESOLVER_MODULE_CACHE = "resolver.cache.module";
    public static final String RESOLVER_TEMPLATE_CACHE =
        "resolver.cache.template";

    /**
     * Home page template.
     */
    public static final String TEMPLATE_HOMEPAGE = "template.homepage";

    /**
     * Login template.
     */
    public static final String TEMPLATE_LOGIN = "template.login";

    /**
     * Login error template.
     */
    public static final String TEMPLATE_ERROR = "template.error";

    /**
     * Home page screen.
     */
    public static final String SCREEN_HOMEPAGE = "screen.homepage";

    /**
     * Login screen.
     */
    public static final String SCREEN_LOGIN = "screen.login";

    /**
     * Login error screen.
     */
    public static final String SCREEN_ERROR = "screen.error";
    public static final String SCREEN_INVALID_STATE = "screen.invalidstate";
    public static final String TEMPLATE_INVALID_STATE = "template.invalidstate";

    /**
     * Action to perform when a user logs in.
     */
    public static final String ACTION_LOGIN = "action.login";

    /**
     * Action to perform when a user logs out.
     */
    public static final String ACTION_LOGOUT = "action.logout";

    /**
     * Actions that performs session validation.
     */
    public static final String ACTION_SESSION_VALIDATOR =
        "action.sessionvalidator";

    /**
     * I don't think this is being used, is it?
     */
    public static final String ACTION_ACCESS_CONTROLLER =
        "action.accesscontroller";

    /**
     * Default layout.
     */
    public static final String LAYOUT_DEFAULT = "layout.default";

    /**
     * Default page property.
     */
    public static final String PAGE_DEFAULT = "page.default";

    /**
     * Default Page module if one isn't specified in TRP.
     */
    public static final String DEFAULT_PAGE_MODULE = "DefaultPage";

    /**
     * Message to display upon successful login.
     */
    public static final String LOGIN_MESSAGE = "login.message";

    /**
     * Message to display when a user fails to login.
     */
    public static final String LOGIN_ERROR = "login.error";

    /**
     * Message to display when screens variable invalid.
     */
    public static final String LOGIN_MESSAGE_NOSCREEN =
        "login.message.noscreen";

    /**
     * Message to display when a user logs out.
     */
    public static final String LOGOUT_MESSAGE = "logout.message";

    /**
     * Indicate whether this Turbine application is using SSL.
     * Used for creating dynamic URIs.
     */
    public static final String USE_SSL = "use.ssl";

    /**
     * Should the PP fold the case of everything. Possible values are
     * "upper", "lower" and "none".
     */
    public static final String PP_URL_CASE_FOLDING = "url.case.folding";

    /**
     * Default document type.
     */
    public static final String DEFAULT_DOCUMENT_TYPE = "default.doctype";

    /**
     * Default value of TurbineResources.properties file path
     * (<code>/WEB-INF/conf/TurbineResources.properties</code>).
     */
    public static final String DEFAULT_TURBINE_RESOURCES =
        "/WEB-INF/conf/TurbineResources.properties";

    public static final String ACTIONS = "actions";
    public static final String PAGES = "pages";
    public static final String LAYOUTS = "layouts";
    public static final String NAVIGATIONS = "navigations";
    public static final String SCREENS = "screens";

    //!! I don't think jobs should be part of the module system
    // at all but will be left for BC for now.
    public static final String JOBS = "scheduledjobs";

    public static final String DEFAULT_MODULE_PACKAGE =
        "org.apache.turbine.modules";

    public static final String SESSION_TIMEOUT = "session.timeout";

    public static final String SCREEN = "screen";
    public static final String ACTION = "action";
    public static final String TEMPLATE = "template";
    
    public static final String CONTEXT = "__template_context__";

    /**
     * Name of path info parameter used to indicate the redirected stage of
     * a given user's initial Turbine request
     */
    public static final String REDIRECTED_PATHINFO_NAME = "redirected";

    /**
     * The base directory key
     */
    public static final String BASEDIR_KEY = "basedir";

    /**
     * Application root key that can be used in the deployment
     * descriptor to change the root directory where a turbine
     * application runs from.
     */
    public static final String APPLICATION_ROOT = "applicationRoot";
    public static final String WEBAPP_ROOT = "webappRoot";
    public static final String WEB_CONTEXT = "webContext";
    public static final String LOGGING_ROOT = "loggingRoot";
    
    /**
     * configuration subset
     */
    public static final String SYSTEM = "system";


    /**
     * Request key where a RunData object may be stored.  Useful in cases
     * where one application is invoked by another.
     */
    public static final String RUNDATA_REQUEST_KEY = 
        "org.apache.turbine.RunData.request.key";

    /**
     * Request key for standalone vs. integrated operation.  If an object
     * exists under this key, integrated operation will be assumed
     * regardless of MODE set in the configuration.
     */
    public static final String INTEGRATED_REQUEST_KEY = 
        "org.apache.turbine.integrated.request.key";

    /**
     * Configuration key for standalone vs. integrated operation.
     */
    public static final String MODE = "turbine.mode";

    /**
     * Configuration value for MODE property, if not set to integrated, 
     * standalone is assumed.
     */
    public static final String INTEGRATED = "integrated";
    
    /** The key for the Log4J File */
    public static final String LOG4J_CONFIG_FILE = "log4j.file";

    /** The default value for the Log4J File */
    public static final String LOG4J_CONFIG_FILE_DEFAULT = "/WEB-INF/conf/log4j.properties";    
}
