package org.apache.turbine;

public abstract class TurbineSecureModule
    extends org.apache.turbine.modules.SecureModule
{
    protected abstract boolean isAuthorized(RunData data)
        throws Exception;
}
