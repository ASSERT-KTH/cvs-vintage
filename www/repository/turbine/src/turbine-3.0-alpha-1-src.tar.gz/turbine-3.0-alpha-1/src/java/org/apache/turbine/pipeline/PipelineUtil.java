package org.apache.turbine.pipeline;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

 /* 
   perhaps this code should go someplace else.
   The following classes use it:
     + DefaultResolver 
     + ModuleRunner
     + modules/ModuleLoader 
*/

/**
 *
 * @author <a href="mailto:mikeh@apache.org">Mike Haberman</a>
 * @version $Id: PipelineUtil.java,v 1.1 2001/11/13 21:35:45 mikeh Exp $
 */

public class PipelineUtil
{
   private PipelineUtil()
   {
   }

    /**
     * Parse the template name collected from URL parameters or
     * template context to a path name. Double slashes are changed
     * into single ones and commas used as path delemiters in
     * URL parameters are changed into slashes. Empty names or
     * names without a file part are not accepted.
     *
     * @param template The template name.
     * @param buffer A buffer for the result.
     * @return The index of the separator between the path and the name.
     * @exception Exception Malformed template name.
     */

    /* 
        TODO: it would be nice to cache this info
    */
    public static int parseTemplatePath(String template,StringBuffer buffer)
        throws Exception
    {
        char c;
        int j = 0;
        int ind = -1;
        buffer.setLength(0);
        buffer.append(template);
        int len = buffer.length();
        while (j < len)
        {
            c = buffer.charAt(j);
            if (c == ',')
            {
                c = '/';
                buffer.setCharAt(j,c);
            }
            if (c == '/')
            {
                ind = j;
                if (j < (len - 1))
                {
                    c = buffer.charAt(j + 1);
                    if ((c == '/') ||
                        (c == ','))
                    {
                        buffer.deleteCharAt(j);
                        len--;
                        continue;
                    }
                }
            }
            j++;
        }
        if ((len == 0) ||
            (ind >= (len - 1)))
        {
            throw new Exception(
                "Syntax error in template name '" + template + '\'');
        }
        return ind;
    }
}
