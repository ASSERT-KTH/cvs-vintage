package org.apache.turbine;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2003 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Tests the DynamicURI class.
 *
 * @author <a href="mailto:jmcnally@apache.org">John McNally</a>
 * @since 3.0
 * @version $Id: DynamicURITest.java,v 1.2 2003/11/23 00:42:22 mpoeschl Exp $
 */
public class DynamicURITest
    extends TestCase
{
    /**
     * Creates a new instance.
     */
    public DynamicURITest(String testName) 
    {
        super(testName);
    }

    /**
     * Return the Test
     */
    public static Test suite() 
    {
        return new TestSuite(DynamicURITest.class);
    }

    /**
     * Setup the test.
     */
    public void setUp() 
    {
        // Nothing done here yet.
    }
   
    /**
     * Tear down the test.
     */
    public void tearDown() 
    {
        // Nothing to do here yet.
    }

    /**
     * Previous versions of DynamicURI immediately converted a pathinfo
     * or query parameter to a byte array for url encoding.  The method
     * has been modified to only invoke the getBytes() method, if a 
     * character requires encoding.  This test compares the results of
     * the new method with the old.
     */
    public void testFastEncoding()
    {
        char[] allchars = new char[65546];
        allchars[0] = 's';
        allchars[1] = 't';
        allchars[2] = 'a';
        allchars[3] = 'r';
        allchars[4] = 't';
        allchars[5] = ' ';
        allchars[6] = 's';
        allchars[7] = 'a';
        allchars[8] = 'f';
        allchars[9] = 'e';
        for (int i=0; i<65536; i++) 
        {
            allchars[i+10] = (char)i;
        }
        final String all = new String(allchars);

        // get reference String
        StringBuffer out = new StringBuffer();
        DynamicURI.writeEncoded(all, out);
        String reference = out.toString();

        // compare to our changes
        out = new StringBuffer();
        DynamicURI.writeFastEncoded(all, out);
        String s = out.toString();

        assertEquals("Test of complete character set failed.", reference, s);

        // colon is a special character
        String in = ":colon as first char";
        // get reference String
        out = new StringBuffer();
        DynamicURI.writeEncoded(in, out);
        reference = out.toString();
        // compare to our changes
        out = new StringBuffer();
        DynamicURI.writeFastEncoded(in, out);
        s = out.toString();

        assertEquals("Special character as first character failed.", reference, s);

        // colon is a special character
        in = "colon as last char:";
        // get reference String
        out = new StringBuffer();
        DynamicURI.writeEncoded(in, out);
        reference = out.toString();
        // compare to our changes
        out = new StringBuffer();
        DynamicURI.writeFastEncoded(in, out);
        s = out.toString();

        assertEquals("Special character as last character failed.", reference, s);

        // colon is a special character
        in = "n0special_chars";
        // get reference String
        out = new StringBuffer();
        DynamicURI.writeEncoded(in, out);
        reference = out.toString();
        // compare to our changes
        out = new StringBuffer();
        DynamicURI.writeFastEncoded(in, out);
        s = out.toString();

        assertEquals("String with no special character failed.", reference, s);
    }
}
