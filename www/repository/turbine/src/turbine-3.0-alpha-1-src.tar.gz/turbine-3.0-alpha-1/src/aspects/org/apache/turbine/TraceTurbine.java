package org.apache.turbine;

/**
 * This class concretizes the abstract crosscut in Trace, 
 * applying the trace facility to these application classes.
 *
 * We will move toward having a set of aspects that define a
 * particular tracing behaviour and then we can control which
 * ones will be applied using an if() designator and some
 * run-time properties. This was originally made to watch
 * the pipeline in action but it will be fleshed out.
 *
 * @author <a href="mailto:jvanzyl@zenplex.com">Jason van Zyl</a>
 * @version $Id: TraceTurbine.java,v 1.2 2002/01/23 04:35:48 jvanzyl Exp $
 */
public aspect TraceTurbine
    extends Trace 
{
    /**
     * A simple selection of classes in the pipeline package.
     */
    pointcut myClass(Object obj): this(obj) && 
        (within(org.apache.turbine.pipeline.*));
}

