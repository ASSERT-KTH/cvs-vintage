--------------------------------------------------------------------------
$Id: README.txt,v 1.3 2002/07/08 08:25:33 dlr Exp $
Turbine Top Level README
--------------------------------------------------------------------------

Welcome to Turbine.

Using Turbine 3.0 is done _entirely_ at your own risk at this point;
the Turbine 3.0 API has not yet been solidified.  We recommend that
people stay with 2.1 until 3.0 is ready.

In order to get started using Turbine, you must build it first.
Please refer to the BUILDING.txt file for details on building Turbine.

For more information about Turbine, please refer to the HTML
documentation in the docs/ directory, or at
<http://jakarta.apache.org/turbine/turbine-3/>.

The top level directories contain:

conf/       Various configuration files.
docs/       Generated (xdoc-based) documentation.
            All of the files in this directory are mirrored onto
            the live website.
misc/       Miscellaneous files.
notes/      Random musings by Turbine developers.
proposals/  Proposed API changes and implementations.
src/        Source code to Turbine.
target/     A temporary directory for building the project.
xdocs/      XML sources for generated documentation.



Thanks,

-The Turbine Team
