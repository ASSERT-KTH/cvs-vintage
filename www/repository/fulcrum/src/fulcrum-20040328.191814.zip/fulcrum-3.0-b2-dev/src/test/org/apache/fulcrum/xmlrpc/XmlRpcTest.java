package org.apache.fulcrum.xmlrpc;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001-2002 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Turbine" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Turbine", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.fulcrum.Fulcrum;
import org.apache.fulcrum.InstantiationException;
import org.apache.fulcrum.ServiceManager;
import org.apache.fulcrum.TurbineServices;

/**
 * Tests the API of the
 * {@link org.apache.fulcrum.xmlrpc.XmlRpcService}.
 * <br>
 *
 * Depends on an external config file definied by CONFIG_FILE
 *
 * @author <a href="mailto:eric@dobbse.net">Eric Dobbs</a>
 */
public class XmlRpcTest
    extends TestCase
{
    public static final String CONFIG_FILE =
        "src/test/org/apache/fulcrum/xmlrpc/Fulcrum.properties";
    private ServiceManager manager = null;
    private Fulcrum fulcrum = null;
    private static boolean initialized = false;

    public XmlRpcTest(String name)
    {
        super(name);
    }

    public void testInitializeTurbineServices()
    {
        // These testInitialize* cases must be synchronized against
        // the class.  JUnit will run them in separate threads.  If
        // testInitializeTurbineServices has not shutdown its
        // XmlRpcService when testInitializeFulcrum runs, the call to
        // TurbineXmlRpc.getService() will get the service in
        // TurbineServices that has not yet shutdown.
        synchronized (XmlRpcTest.class)
        {
            initTurbineServices();
            try
            {
                XmlRpcService xmlrpc = TurbineXmlRpc.getService();
                assertNotNull(xmlrpc);
                assertTrue(xmlrpc.isInitialized());
            }
            catch (InstantiationException ie)
            {
                fail("could not get the service: " + XmlRpcService.SERVICE_NAME);
            }
            shutdownTurbineServices();
        }
    }

    public void testInitializeFulcrum()
    {
        synchronized (XmlRpcTest.class)
        {
            initFulcrum();
            try
            {
                XmlRpcService xmlrpc = TurbineXmlRpc.getService();
                assertNotNull(xmlrpc);
                assertTrue(xmlrpc.isInitialized());
            }
            catch (InstantiationException ie)
            {
                fail("could not get the service: " + XmlRpcService.SERVICE_NAME);
            }
            shutdownFulcrum();
        }
    }

    /**
     * Configures and initializes Fulcrum in the same way that
     * Stratum's ComponentLoader does.
     */
    private void initFulcrum()
    {
        try
        {
            fulcrum = new Fulcrum();
            fulcrum.configure(new PropertiesConfiguration(CONFIG_FILE));
            fulcrum.initialize();
        }
        catch (IOException ioe)
        {
            reportIOExceptionAndFail("Fulcrum",ioe);
        }
        catch (Exception e)
        {
            reportExceptionAndFail("Fulcrum",e);
        }
    }

    private void initTurbineServices()
    {
        try
        {
            manager = TurbineServices.getInstance();
            manager.setConfiguration(new PropertiesConfiguration(CONFIG_FILE));
            manager.init();
        }
     
        catch (Exception e)
        {
            reportExceptionAndFail("Fulcrum",e);
        }
    }

    private void shutdownFulcrum()
    {
        fulcrum.shutdownServices();
    }

    private void shutdownTurbineServices()
    {
        manager.shutdownServices();
    }

    private void reportIOExceptionAndFail(String name, IOException ioe)
    {
        String errorMessage = name +" could not be configured with file '"
            + CONFIG_FILE + "'.";
        ioe.printStackTrace();
        fail(errorMessage);
    }

    private void reportExceptionAndFail(String name, Exception e)
    {
        String errorMessage = name + " could not be initialized!";
        e.printStackTrace();
        fail(errorMessage);
    }
}
